/* Service worker – pełna praca offline (aplikacja + dokumenty PDF) */
const VERSION = 'kq-2026-10-02-3';
const SHELL = [
  './', './index.html', './css/app.css', './js/app.js', './js/data.js', './js/acts.js', './js/questions.js',
  './manifest.webmanifest', './icons/icon.svg', './icons/icon-192.png', './icons/icon-512.png', './icons/icon-maskable-512.png'
];
const DOCS = [
  './docs/rozp-kwalifikacje-gornicze-2024-992.pdf', './docs/pgg-tekst-jednolity-2026-69.pdf',
  './docs/rozp-kwalifikacje-geologia-2026-249.pdf', './docs/pytania-geolog-gorniczy-2026.pdf',
  './docs/pytania-mierniczy-gorniczy-2026.pdf', './docs/rozp-oug-2022-525.pdf'
];
self.addEventListener('install', (e) => {
  e.waitUntil(caches.open(VERSION).then(async (c) => {
    await c.addAll(SHELL);
    await Promise.all(DOCS.map((u) => c.add(u).catch(() => {})));
  }).then(() => self.skipWaiting()));
});
self.addEventListener('activate', (e) => {
  e.waitUntil(caches.keys().then((ks) => Promise.all(ks.filter((k) => k !== VERSION).map((k) => caches.delete(k)))).then(() => self.clients.claim()));
});
self.addEventListener('fetch', (e) => {
  const url = new URL(e.request.url);
  if (e.request.method !== 'GET' || url.origin !== location.origin) return;
  const isStatic = /\/(docs|icons)\//.test(url.pathname);
  const put = (res) => { if (res.ok) { const copy = res.clone(); caches.open(VERSION).then((c) => c.put(e.request, copy)); } return res; };
  if (isStatic) {
    // PDF-y i ikony: najpierw cache
    e.respondWith(caches.match(e.request, { ignoreSearch: true }).then((hit) => hit || fetch(e.request).then(put)));
  } else {
    // kod i dane: najpierw sieć (aktualizacje), offline – cache
    e.respondWith(fetch(e.request).then(put).catch(() => caches.match(e.request, { ignoreSearch: true }).then((hit) => hit || caches.match('./index.html'))));
  }
});
