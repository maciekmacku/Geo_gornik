// Akty z zestawienia WUG „Wymagana wiedza w zakresie prawa”, zweryfikowane w API Sejmu (ELI) 2.10.2026
window.ACTS=[
{
"title": "Ustawa z dnia 9 czerwca 2011 r. - Prawo geologiczne i górnicze",
"addr": "Dz.U. 2011 nr 163 poz. 981",
"isap": "WDU20111630981",
"status": "akt posiada tekst jednolity",
"tj": "DU/2026/69",
"id": "a00",
"tags": [
"all"
],
"url": "https://isap.sejm.gov.pl/isap.nsf/DocDetails.xsp?id=WDU20111630981",
"tjAddr": "Dz.U. 2026 poz. 69",
"tjUrl": "https://isap.sejm.gov.pl/isap.nsf/DocDetails.xsp?id=WDU20260000069"
},
{
"title": "Rozporządzenie Ministra Przemysłu z dnia 25 czerwca 2024 r. w sprawie kwalifikacji w zakresie górnictwa i ratownictwa górniczego",
"addr": "Dz.U. 2024 poz. 992",
"isap": "WDU20240000992",
"status": "obowiązujący",
"tj": null,
"id": "a01",
"tags": [
"all"
],
"url": "https://isap.sejm.gov.pl/isap.nsf/DocDetails.xsp?id=WDU20240000992"
},
{
"title": "Rozporządzenie Ministra Klimatu i Środowiska z dnia 11 lutego 2026 r. w sprawie kwalifikacji w zakresie geologii",
"addr": "Dz.U. 2026 poz. 249",
"isap": "WDU20260000249",
"status": "obowiązujący",
"tj": null,
"note": "Nowe – obowiązuje od 17.03.2026 (14 dni od ogłoszenia 2.03.2026).",
"id": "a02",
"tags": [
"geologia"
],
"url": "https://isap.sejm.gov.pl/isap.nsf/DocDetails.xsp?id=WDU20260000249"
},
{
"title": "Rozporządzenie Ministra Środowiska z dnia 8 grudnia 2017 r. w sprawie planów ruchu zakładów górniczych",
"addr": "Dz.U. 2017 poz. 2293",
"isap": "WDU20170002293",
"status": "obowiązujący",
"tj": null,
"id": "a03",
"tags": [
"gornictwo",
"mierniczy",
"geolog"
],
"url": "https://isap.sejm.gov.pl/isap.nsf/DocDetails.xsp?id=WDU20170002293"
},
{
"title": "Rozporządzenie Rady Ministrów z dnia 30 kwietnia 2004 r. w sprawie dopuszczania wyrobów do stosowania w zakładach górniczych",
"addr": "Dz.U. 2004 nr 99 poz. 1003",
"isap": "WDU20040991003",
"status": "obowiązujący",
"tj": null,
"id": "a04",
"tags": [
"gornictwo",
"mierniczy",
"geolog"
],
"url": "https://isap.sejm.gov.pl/isap.nsf/DocDetails.xsp?id=WDU20040991003"
},
{
"title": "Rozporządzenie Ministra Środowiska z dnia 28 października 2015 r. w sprawie dokumentacji mierniczo-geologicznej",
"addr": "Dz.U. 2015 poz. 1941",
"isap": "WDU20150001941",
"status": "obowiązujący",
"tj": null,
"id": "a05",
"tags": [
"mierniczy",
"geolog",
"gornictwo"
],
"url": "https://isap.sejm.gov.pl/isap.nsf/DocDetails.xsp?id=WDU20150001941"
},
{
"title": "Rozporządzenie Ministra Środowiska z dnia 29 stycznia 2013 r. w sprawie zagrożeń naturalnych w zakładach górniczych",
"addr": "Dz.U. 2013 poz. 230",
"isap": "WDU20130000230",
"status": "akt posiada tekst jednolity",
"tj": "DU/2021/1617",
"id": "a06",
"tags": [
"gornictwo",
"mierniczy",
"geolog"
],
"url": "https://isap.sejm.gov.pl/isap.nsf/DocDetails.xsp?id=WDU20130000230",
"tjAddr": "Dz.U. 2021 poz. 1617",
"tjUrl": "https://isap.sejm.gov.pl/isap.nsf/DocDetails.xsp?id=WDU20210001617"
},
{
"title": "Rozporządzenie Ministra Energii z dnia 23 listopada 2016 r. w sprawie szczegółowych wymagań dotyczących prowadzenia ruchu podziemnych zakładów górniczych",
"addr": "Dz.U. 2017 poz. 1118",
"isap": "WDU20170001118",
"status": "obowiązujący",
"tj": null,
"id": "a07",
"tags": [
"podziemne",
"mierniczy",
"geolog",
"ratownictwo"
],
"url": "https://isap.sejm.gov.pl/isap.nsf/DocDetails.xsp?id=WDU20170001118"
},
{
"title": "Rozporządzenie Ministra Gospodarki z dnia 25 kwietnia 2014 r. w sprawie szczegółowych wymagań dotyczących prowadzenia ruchu zakładów górniczych wydobywających kopaliny otworami wiertniczymi",
"addr": "Dz.U. 2014 poz. 812",
"isap": "WDU20140000812",
"status": "obowiązujący",
"tj": null,
"id": "a08",
"tags": [
"otworowe",
"mierniczy",
"geolog"
],
"url": "https://isap.sejm.gov.pl/isap.nsf/DocDetails.xsp?id=WDU20140000812"
},
{
"title": "Rozporządzenie Ministra Gospodarki z dnia 8 kwietnia 2013 r. w sprawie szczegółowych wymagań dotyczących prowadzenia ruchu odkrywkowego zakładu górniczego",
"addr": "Dz.U. 2013 poz. 1008",
"isap": "WDU20130001008",
"status": "obowiązujący",
"tj": null,
"id": "a09",
"tags": [
"odkrywkowe",
"mierniczy",
"geolog"
],
"url": "https://isap.sejm.gov.pl/isap.nsf/DocDetails.xsp?id=WDU20130001008"
},
{
"title": "Rozporządzenie Ministra Energii z dnia 9 listopada 2016 r. w sprawie szczegółowych wymagań dotyczących przechowywania i używania środków strzałowych i sprzętu strzałowego w ruchu zakładu górniczego",
"addr": "Dz.U. 2017 poz. 321",
"isap": "WDU20170000321",
"status": "obowiązujący",
"tj": null,
"id": "a10",
"tags": [
"gornictwo",
"otworowe"
],
"url": "https://isap.sejm.gov.pl/isap.nsf/DocDetails.xsp?id=WDU20170000321"
},
{
"title": "Rozporządzenie Ministra Energii z dnia 16 marca 2017 r. w sprawie ratownictwa górniczego",
"addr": "Dz.U. 2017 poz. 1052",
"isap": "WDU20170001052",
"status": "akt posiada tekst jednolity",
"tj": null,
"id": "a11",
"tags": [
"ratownictwo",
"podziemne",
"gornictwo"
],
"url": "https://isap.sejm.gov.pl/isap.nsf/DocDetails.xsp?id=WDU20170001052"
},
{
"title": "Rozporządzenie Ministra Aktywów Państwowych z dnia 1 marca 2022 r. w sprawie określenia nazw, siedzib i właściwości miejscowej okręgowych urzędów górniczych oraz zniesienia Okręgowego Urzędu Górniczego w Gliwicach",
"addr": "Dz.U. 2022 poz. 525",
"isap": "WDU20220000525",
"status": "obowiązujący",
"tj": null,
"id": "a12",
"tags": [
"gornictwo",
"mierniczy",
"geolog"
],
"url": "https://isap.sejm.gov.pl/isap.nsf/DocDetails.xsp?id=WDU20220000525"
},
{
"title": "Rozporządzenie Rady Ministrów z dnia 10 stycznia 2012 r. w sprawie przetargu na ustanowienie użytkowania górniczego",
"addr": "Dz.U. 2012 poz. 101",
"isap": "WDU20120000101",
"status": "uznany za uchylony",
"tj": null,
"id": "a13",
"tags": [
"geologia",
"geolog",
"otworowe"
],
"url": "https://isap.sejm.gov.pl/isap.nsf/DocDetails.xsp?id=WDU20120000101"
},
{
"title": "Rozporządzenie Ministra Środowiska z dnia 24 kwietnia 2012 r. w sprawie szczegółowych wymagań dotyczących projektów zagospodarowania złóż",
"addr": "Dz.U. 2012 poz. 511",
"isap": "WDU20120000511",
"status": "obowiązujący",
"tj": null,
"id": "a14",
"tags": [
"geologia",
"geolog",
"otworowe"
],
"url": "https://isap.sejm.gov.pl/isap.nsf/DocDetails.xsp?id=WDU20120000511"
},
{
"title": "Rozporządzenie Ministra Środowiska z dnia 16 października 2014 r. w sprawie rejestru obszarów górniczych i zamkniętych podziemnych składowisk dwutlenku węgla",
"addr": "Dz.U. 2014 poz. 1469",
"isap": "WDU20140001469",
"status": "obowiązujący",
"tj": null,
"id": "a15",
"tags": [
"geologia",
"geolog",
"otworowe"
],
"url": "https://isap.sejm.gov.pl/isap.nsf/DocDetails.xsp?id=WDU20140001469"
},
{
"title": "Rozporządzenie Ministra Klimatu i Środowiska z dnia 23 sierpnia 2023 r. w sprawie kwalifikacji w zakresie geologii",
"addr": "Dz.U. 2023 poz. 1756",
"isap": "WDU20230001756",
"status": "uznany za uchylony",
"tj": null,
"note": "Uchylone – zastąpione rozporządzeniem MKiŚ z 11 lutego 2026 r. (Dz.U. 2026 poz. 249). Lista WUG nie została jeszcze zaktualizowana.",
"id": "a16",
"tags": [
"geologia"
],
"url": "https://isap.sejm.gov.pl/isap.nsf/DocDetails.xsp?id=WDU20230001756"
},
{
"title": "Rozporządzenie Ministra Środowiska z dnia 20 grudnia 2011 r. w sprawie szczegółowych wymagań dotyczących projektów robót geologicznych, w tym robót, których wykonywanie wymaga uzyskania koncesji",
"addr": "Dz.U. 2011 nr 288 poz. 1696",
"isap": "WDU20112881696",
"status": "akt posiada tekst jednolity",
"tj": "DU/2023/155",
"id": "a17",
"tags": [
"geologia",
"geolog",
"otworowe"
],
"url": "https://isap.sejm.gov.pl/isap.nsf/DocDetails.xsp?id=WDU20112881696",
"tjAddr": "Dz.U. 2023 poz. 155",
"tjUrl": "https://isap.sejm.gov.pl/isap.nsf/DocDetails.xsp?id=WDU20230000155"
},
{
"title": "Rozporządzenie Ministra Środowiska z dnia 1 lipca 2015 r. w sprawie dokumentacji geologicznej złoża kopaliny, z wyłączeniem złoża węglowodorów",
"addr": "Dz.U. 2015 poz. 987",
"isap": "WDU20150000987",
"status": "obowiązujący",
"tj": null,
"id": "a18",
"tags": [
"geologia",
"geolog",
"otworowe"
],
"url": "https://isap.sejm.gov.pl/isap.nsf/DocDetails.xsp?id=WDU20150000987"
},
{
"title": "Rozporządzenie Ministra Środowiska z dnia 1 lipca 2015 r. w sprawie dokumentacji gologiczno-inwestycyjnej złoża węglowodorów",
"addr": "Dz.U. 2015 poz. 968",
"isap": "WDU20150000968",
"status": "obowiązujący",
"tj": null,
"id": "a19",
"tags": [
"inne",
"gornictwo"
],
"url": "https://isap.sejm.gov.pl/isap.nsf/DocDetails.xsp?id=WDU20150000968"
},
{
"title": "Rozporządzenie Ministra Środowiska z dnia 18 listopada 2016 r. w sprawie dokumentacji hydrogeologicznej i dokumentacji geologiczno-inżynierskiej",
"addr": "Dz.U. 2016 poz. 2033",
"isap": "WDU20160002033",
"status": "obowiązujący",
"tj": null,
"id": "a20",
"tags": [
"geologia",
"geolog",
"otworowe"
],
"url": "https://isap.sejm.gov.pl/isap.nsf/DocDetails.xsp?id=WDU20160002033"
},
{
"title": "Rozporządzenie Ministra Środowiska z dnia 6 grudnia 2016 r. w sprawie innych dokumentacji geologicznych",
"addr": "Dz.U. 2016 poz. 2023",
"isap": "WDU20160002023",
"status": "uznany za uchylony",
"tj": null,
"id": "a21",
"tags": [
"geologia",
"geolog",
"otworowe"
],
"url": "https://isap.sejm.gov.pl/isap.nsf/DocDetails.xsp?id=WDU20160002023"
},
{
"title": "Rozporządzenie Ministra Środowiska z dnia 20 grudnia 2011 r. w sprawie korzystania z informacji geologicznej za wynagrodzeniem",
"addr": "Dz.U. 2011 nr 292 poz. 1724",
"isap": "WDU20112921724",
"status": "obowiązujący",
"tj": null,
"id": "a22",
"tags": [
"geologia",
"geolog",
"otworowe"
],
"url": "https://isap.sejm.gov.pl/isap.nsf/DocDetails.xsp?id=WDU20112921724"
},
{
"title": "Rozporządzenie Ministra Środowiska z dnia 15 listopada 2011 r. w sprawie operatu ewidencyjnego oraz wzorów informacji o zmianach zasobów złoża kopaliny",
"addr": "Dz.U. 2011 nr 262 poz. 1568",
"isap": "WDU20112621568",
"status": "akt posiada tekst jednolity",
"tj": "DU/2021/998",
"id": "a23",
"tags": [
"mierniczy",
"geolog",
"gornictwo"
],
"url": "https://isap.sejm.gov.pl/isap.nsf/DocDetails.xsp?id=WDU20112621568",
"tjAddr": "Dz.U. 2021 poz. 998",
"tjUrl": "https://isap.sejm.gov.pl/isap.nsf/DocDetails.xsp?id=WDU20210000998"
},
{
"title": "Rozporządzenie Ministra Środowiska z dnia 25 lutego 2015 r. w sprawie wzorów druków informacji dotyczącej opłaty z zakresu przepisów Prawa geologicznego i górniczego",
"addr": null,
"isap": null,
"status": null,
"tj": null,
"id": "a24",
"tags": [
"geologia",
"geolog",
"otworowe"
],
"url": null
},
{
"title": "Rozporządzenie Ministra Środowiska z dnia 8 maja 2014 r. w sprawie szczegółowych wymagań, jakim powinien odpowiadać plan zagospodarowania podziemnego składowiska dwutlenku węgla",
"addr": "Dz.U. 2014 poz. 591",
"isap": "WDU20140000591",
"status": "obowiązujący",
"tj": null,
"id": "a25",
"tags": [
"geologia",
"geolog",
"otworowe"
],
"url": "https://isap.sejm.gov.pl/isap.nsf/DocDetails.xsp?id=WDU20140000591"
},
{
"title": "Rozporządzenie Ministra Środowiska z dnia 3 września 2014 r. w sprawie obszarów, na których dopuszcza się lokalizowanie kompleksu podziemnego składowania dwutlenku węgla",
"addr": "Dz.U. 2014 poz. 1272",
"isap": "WDU20140001272",
"status": "obowiązujący",
"tj": null,
"id": "a26",
"tags": [
"geologia",
"geolog",
"otworowe"
],
"url": "https://isap.sejm.gov.pl/isap.nsf/DocDetails.xsp?id=WDU20140001272"
},
{
"title": "Rozporządzenie Rady Ministrów z dnia 20 kwietnia 2015 r. w sprawie wniosku o przeprowadzenie postępowania kwalifikacyjnego",
"addr": "Dz.U. 2015 poz. 708",
"isap": "WDU20150000708",
"status": "uznany za uchylony",
"tj": null,
"id": "a27",
"tags": [
"geologia",
"geolog",
"otworowe"
],
"url": "https://isap.sejm.gov.pl/isap.nsf/DocDetails.xsp?id=WDU20150000708"
},
{
"title": "Rozporządzenie Ministra Środowiska z dnia 9 czerwca 2015 r. w sprawie przekazywania informacji z bieżącego dokumentowania przebiegu prac geologicznych",
"addr": "Dz.U. 2015 poz. 903",
"isap": "WDU20150000903",
"status": "uznany za uchylony",
"tj": null,
"id": "a28",
"tags": [
"geologia",
"geolog",
"otworowe"
],
"url": "https://isap.sejm.gov.pl/isap.nsf/DocDetails.xsp?id=WDU20150000903"
},
{
"title": "Rozporządzenie Rady Ministrów z dnia 28 lipca 2015 r. w sprawie przetargu na udzielenie koncesji na poszukiwanie i rozpoznawanie złoża węglowodorów oraz wydobywanie węglowodorów ze złoża, a także koncesji na wydobywanie węglowodorów ze złoża",
"addr": "Dz.U. 2015 poz. 1171",
"isap": "WDU20150001171",
"status": "obowiązujący",
"tj": null,
"id": "a29",
"tags": [
"geologia",
"geolog",
"otworowe"
],
"url": "https://isap.sejm.gov.pl/isap.nsf/DocDetails.xsp?id=WDU20150001171"
},
{
"title": "Rozporządzenie Ministra Środowiska z dnia 30 października 2015 r. w sprawie szczegółowych wymagań dotyczących eksploatacji podziemnego składowiska dwutlenku węgla, zatłaczanego strumienia dwutlenku węgla oraz prowadzenia monitoringu kompleksu podziemnego składowania dwutlenku węgla",
"addr": "Dz.U. 2015 poz. 1840",
"isap": "WDU20150001840",
"status": "obowiązujący",
"tj": null,
"id": "a30",
"tags": [
"geologia",
"geolog",
"otworowe"
],
"url": "https://isap.sejm.gov.pl/isap.nsf/DocDetails.xsp?id=WDU20150001840"
},
{
"title": "Rozporządzenie Ministra Środowiska z dnia 30 października 2015 r. w sprawie zabezpieczenia finansowego i zabezpieczenia środków związanych z podziemnym składowaniem dwutlenku węgla",
"addr": "Dz.U. 2015 poz. 2144",
"isap": "WDU20150002144",
"status": "obowiązujący",
"tj": null,
"id": "a31",
"tags": [
"geologia",
"geolog",
"otworowe"
],
"url": "https://isap.sejm.gov.pl/isap.nsf/DocDetails.xsp?id=WDU20150002144"
},
{
"title": "Ustawa z dnia 27 kwietnia 2001 r. - Prawo ochrony środowiska",
"addr": "Dz.U. 2001 nr 62 poz. 627",
"isap": "WDU20010620627",
"status": "akt posiada tekst jednolity",
"tj": "DU/2025/647",
"id": "a32",
"tags": [
"inne",
"gornictwo"
],
"url": "https://isap.sejm.gov.pl/isap.nsf/DocDetails.xsp?id=WDU20010620627",
"tjAddr": "Dz.U. 2025 poz. 647",
"tjUrl": "https://isap.sejm.gov.pl/isap.nsf/DocDetails.xsp?id=WDU20250000647"
},
{
"title": "Ustawa z dnia 20 lipca 2017 r. - Prawo wodne",
"addr": "Dz.U. 2017 poz. 1566",
"isap": "WDU20170001566",
"status": "akt posiada tekst jednolity",
"tj": "DU/2025/960",
"id": "a33",
"tags": [
"inne",
"gornictwo"
],
"url": "https://isap.sejm.gov.pl/isap.nsf/DocDetails.xsp?id=WDU20170001566",
"tjAddr": "Dz.U. 2025 poz. 960",
"tjUrl": "https://isap.sejm.gov.pl/isap.nsf/DocDetails.xsp?id=WDU20250000960"
},
{
"title": "Ustawa z dnia 7 lipca 1994 r. - Prawo budowlane",
"addr": "Dz.U. 1994 nr 89 poz. 414",
"isap": "WDU19940890414",
"status": "akt posiada tekst jednolity",
"tj": "DU/2026/524",
"id": "a34",
"tags": [
"inne",
"gornictwo"
],
"url": "https://isap.sejm.gov.pl/isap.nsf/DocDetails.xsp?id=WDU19940890414",
"tjAddr": "Dz.U. 2026 poz. 524",
"tjUrl": "https://isap.sejm.gov.pl/isap.nsf/DocDetails.xsp?id=WDU20260000524"
},
{
"title": "Ustawa z dnia 27 marca 2003 r. o planowaniu i zagospodarowaniu przestrzennym",
"addr": "Dz.U. 2003 nr 80 poz. 717",
"isap": "WDU20030800717",
"status": "akt posiada tekst jednolity",
"tj": "DU/2026/538",
"id": "a35",
"tags": [
"inne",
"gornictwo"
],
"url": "https://isap.sejm.gov.pl/isap.nsf/DocDetails.xsp?id=WDU20030800717",
"tjAddr": "Dz.U. 2026 poz. 538",
"tjUrl": "https://isap.sejm.gov.pl/isap.nsf/DocDetails.xsp?id=WDU20260000538"
},
{
"title": "Ustawa z dnia 17 maja 1989 r. - Prawo geodezyjne i kartograficzne",
"addr": "Dz.U. 1989 nr 30 poz. 163",
"isap": "WDU19890300163",
"status": "akt posiada tekst jednolity",
"tj": "DU/2024/1151",
"id": "a36",
"tags": [
"inne",
"gornictwo"
],
"url": "https://isap.sejm.gov.pl/isap.nsf/DocDetails.xsp?id=WDU19890300163",
"tjAddr": "Dz.U. 2024 poz. 1151",
"tjUrl": "https://isap.sejm.gov.pl/isap.nsf/DocDetails.xsp?id=WDU20240001151"
},
{
"title": "Ustawa z dnia 30 sierpnia 2002 r. o systemie oceny zgodności",
"addr": "Dz.U. 2002 nr 166 poz. 1360",
"isap": "WDU20021661360",
"status": "akt posiada tekst jednolity",
"tj": "DU/2023/215",
"id": "a37",
"tags": [
"inne",
"gornictwo"
],
"url": "https://isap.sejm.gov.pl/isap.nsf/DocDetails.xsp?id=WDU20021661360",
"tjAddr": "Dz.U. 2023 poz. 215",
"tjUrl": "https://isap.sejm.gov.pl/isap.nsf/DocDetails.xsp?id=WDU20230000215"
},
{
"title": "Ustawa z dnia 13 kwietnia 2016 r. o systemach oceny zgodności i nadzoru rynku",
"addr": "Dz.U. 2016 poz. 542",
"isap": "WDU20160000542",
"status": "akt posiada tekst jednolity",
"tj": "DU/2025/568",
"id": "a38",
"tags": [
"inne",
"gornictwo"
],
"url": "https://isap.sejm.gov.pl/isap.nsf/DocDetails.xsp?id=WDU20160000542",
"tjAddr": "Dz.U. 2025 poz. 568",
"tjUrl": "https://isap.sejm.gov.pl/isap.nsf/DocDetails.xsp?id=WDU20250000568"
},
{
"title": "Ustawa z dnia 21 czerwca 2002 r. o materiałach wybuchowych przeznaczonych do użytku cywilnego",
"addr": "Dz.U. 2002 nr 117 poz. 1007",
"isap": "WDU20021171007",
"status": "akt posiada tekst jednolity",
"tj": "DU/2022/2378",
"id": "a39",
"tags": [
"gornictwo",
"otworowe"
],
"url": "https://isap.sejm.gov.pl/isap.nsf/DocDetails.xsp?id=WDU20021171007",
"tjAddr": "Dz.U. 2022 poz. 2378",
"tjUrl": "https://isap.sejm.gov.pl/isap.nsf/DocDetails.xsp?id=WDU20220002378"
},
{
"title": "Ustawa z dnia 26 czerwca 1974 r. – Kodeks pracy (Dział X – Bezpieczeństwo i higiena pracy)",
"addr": "Dz.U. 1974 nr 24 poz. 141",
"isap": "WDU19740240141",
"status": "akt posiada tekst jednolity",
"tj": null,
"id": "a40",
"tags": [
"bhp",
"gornictwo"
],
"url": "https://isap.sejm.gov.pl/isap.nsf/DocDetails.xsp?id=WDU19740240141"
},
{
"title": "Rozporządzenie Ministra Pracy i Polityki Socjalnej z dnia 26 września 1997 r. w sprawie ogólnych przepisów bezpieczeństwa i higieny pracy",
"addr": "Dz.U. 1997 nr 129 poz. 844",
"isap": "WDU19971290844",
"status": "akt posiada tekst jednolity",
"tj": "DU/2003/1650",
"id": "a41",
"tags": [
"bhp",
"gornictwo"
],
"url": "https://isap.sejm.gov.pl/isap.nsf/DocDetails.xsp?id=WDU19971290844",
"tjAddr": "Dz.U. 2003 poz. 1650",
"tjUrl": "https://isap.sejm.gov.pl/isap.nsf/DocDetails.xsp?id=WDU20030001650"
},
{
"title": "Rozporządzenie Ministra Energii z dnia 28 sierpnia 2019 r. w sprawie bezpieczeństwa i higieny pracy przy urządzeniach energetycznych",
"addr": "Dz.U. 2019 poz. 1830",
"isap": "WDU20190001830",
"status": "akt posiada tekst jednolity",
"tj": "DU/2021/1210",
"id": "a42",
"tags": [
"bhp",
"gornictwo"
],
"url": "https://isap.sejm.gov.pl/isap.nsf/DocDetails.xsp?id=WDU20190001830",
"tjAddr": "Dz.U. 2021 poz. 1210",
"tjUrl": "https://isap.sejm.gov.pl/isap.nsf/DocDetails.xsp?id=WDU20210001210"
},
{
"title": "Rozporządzenie Ministra Gospodarki z dnia 27 kwietnia 2000 r. w sprawie bezpieczeństwa i higieny pracy przy pracach spawalniczych",
"addr": "Dz.U. 2000 nr 40 poz. 470",
"isap": "WDU20000400470",
"status": "obowiązujący",
"tj": null,
"id": "a43",
"tags": [
"bhp",
"gornictwo"
],
"url": "https://isap.sejm.gov.pl/isap.nsf/DocDetails.xsp?id=WDU20000400470"
},
{
"title": "Rozporządzenie Ministra Gospodarki z dnia 20 września 2001 r. w sprawie bezpieczeństwa i higieny pracy podczas eksploatacji maszyn i innych urządzeń technicznych do robót ziemnych, budowlanych i drogowych",
"addr": "Dz.U. 2001 nr 118 poz. 1263",
"isap": "WDU20011181263",
"status": "akt posiada tekst jednolity",
"tj": "DU/2018/583",
"id": "a44",
"tags": [
"bhp",
"gornictwo"
],
"url": "https://isap.sejm.gov.pl/isap.nsf/DocDetails.xsp?id=WDU20011181263",
"tjAddr": "Dz.U. 2018 poz. 583",
"tjUrl": "https://isap.sejm.gov.pl/isap.nsf/DocDetails.xsp?id=WDU20180000583"
},
{
"title": "Rozporządzenie Ministra Gospodarki z dnia 30 października 2002 r. w sprawie minimalnych wymagań dotyczących bezpieczeństwa i higieny pracy w zakresie użytkowania maszyn przez pracowników podczas pracy",
"addr": "Dz.U. 2002 nr 191 poz. 1596",
"isap": "WDU20021911596",
"status": "obowiązujący",
"tj": null,
"id": "a45",
"tags": [
"bhp",
"gornictwo"
],
"url": "https://isap.sejm.gov.pl/isap.nsf/DocDetails.xsp?id=WDU20021911596"
},
{
"title": "Rozporządzenie Ministra Infrastruktury z dnia 6 lutego 2003 r. w sprawie bezpieczeństwa i higieny pracy podczas wykonywania robót budowlanych",
"addr": "Dz.U. 2003 nr 47 poz. 401",
"isap": "WDU20030470401",
"status": "obowiązujący",
"tj": null,
"id": "a46",
"tags": [
"bhp",
"gornictwo"
],
"url": "https://isap.sejm.gov.pl/isap.nsf/DocDetails.xsp?id=WDU20030470401"
},
{
"title": "Rozporządzenie Ministra Gospodarki i Pracy z dnia 5 sierpnia 2005 r. w sprawie bezpieczeństwa i higieny pracy przy pracach związanych z narażeniem na hałas lub drgania mechaniczne",
"addr": "Dz.U. 2005 nr 157 poz. 1318",
"isap": "WDU20051571318",
"status": "obowiązujący",
"tj": null,
"id": "a47",
"tags": [
"bhp",
"gornictwo"
],
"url": "https://isap.sejm.gov.pl/isap.nsf/DocDetails.xsp?id=WDU20051571318"
},
{
"title": "Rozporządzenie Ministra Rozwoju z dnia 6 czerwca 2016 r. w sprawie wymagań dla urządzeń i systemów ochronnych przeznaczonych do użytku w atmosferze potencjalnie wybuchowej",
"addr": "Dz.U. 2016 poz. 817",
"isap": "WDU20160000817",
"status": "obowiązujący",
"tj": null,
"id": "a48",
"tags": [
"bhp",
"gornictwo"
],
"url": "https://isap.sejm.gov.pl/isap.nsf/DocDetails.xsp?id=WDU20160000817"
}
];
