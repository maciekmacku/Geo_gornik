/* Kompendium kwalifikacji górniczych – logika aplikacji (bez zależności) */
(function () {
  'use strict';

  const $ = (s, el = document) => el.querySelector(s);
  const $$ = (s, el = document) => Array.from(el.querySelectorAll(s));
  const main = $('#main');
  const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const norm = (s) => String(s || '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/ł/g, 'l');

  // ── Pamięć lokalna (bezpieczna) ──
  const store = {
    get(k, d) { try { const v = localStorage.getItem('kq.' + k); return v == null ? d : JSON.parse(v); } catch (e) { return d; } },
    set(k, v) { try { localStorage.setItem('kq.' + k, JSON.stringify(v)); } catch (e) { /* tryb prywatny */ } }
  };

  // ── Motyw ──
  const applyTheme = (t) => { if (t) document.documentElement.setAttribute('data-theme', t); else document.documentElement.removeAttribute('data-theme'); };
  applyTheme(store.get('theme', null));
  $('#themeBtn').addEventListener('click', () => {
    const cur = document.documentElement.getAttribute('data-theme') || (matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light');
    const next = cur === 'dark' ? 'light' : 'dark';
    applyTheme(next); store.set('theme', next);
  });

  const toast = (msg) => { const t = $('#toast'); t.textContent = msg; t.classList.add('show'); clearTimeout(toast._t); toast._t = setTimeout(() => t.classList.remove('show'), 2200); };

  // ── Pomocnicze ──
  const Q = (id) => QUALS.find((q) => q.id === id);
  const organ = (k) => ORGANS[k];
  const tableById = (id) => TABLES.find((t) => t.id === id);
  const pdfPage = (doc, page) => `${META.docs[doc]}#page=${page}`;
  const artLink = (n, label) => { const p = META.pggPage[n]; return p ? `<a href="${pdfPage('pgg', p)}" target="_blank" rel="noopener">${esc(label || 'art. ' + n + ' Pgg')}</a>` : esc(label || 'art. ' + n + ' Pgg'); };
  const ext = (url, label) => `<a href="${esc(url)}" target="_blank" rel="noopener">${esc(label)}</a>`;
  const fmtMonths = (m) => { if (m == null) return '—'; if (m % 12 === 0 && m >= 12) { const y = m / 12; return y + (y === 1 ? ' rok' : y < 5 ? ' lata' : ' lat'); } return m + (m === 1 ? ' miesiąc' : (m % 10 >= 2 && m % 10 <= 4 && (m < 10 || m > 20)) ? ' miesiące' : ' miesięcy'); };
  const organChip = (k) => {
    const cls = { OUG: 'info', WUG: 'accent', MKIS: 'ok', MARSZ: 'ok', PRAC: '' }[k] || '';
    return `<span class="chip ${cls}">${esc(ORGANS[k].short)}</span>`;
  };

  // ── Router ──
  const routes = {};
  const route = (name, fn) => { routes[name] = fn; };
  function parseHash() {
    const h = location.hash.replace(/^#\/?/, '');
    const [path, qs] = h.split('?');
    const parts = path.split('/').filter(Boolean);
    const params = new URLSearchParams(qs || '');
    return { parts, params };
  }
  function render() {
    const { parts, params } = parseHash();
    const name = parts[0] || 'start';
    const fn = routes[name] || routes.start;
    main.innerHTML = '';
    fn(parts.slice(1), params);
    $$('#nav a').forEach((a) => a.setAttribute('aria-current', a.dataset.nav === (name === 'k' ? 'kwalifikacje' : name === 'szukaj' ? '' : name) ? 'page' : 'false'));
    if (!render._first) { window.scrollTo(0, 0); main.focus({ preventScroll: true }); }
    render._first = false;
  }
  render._first = true;
  window.addEventListener('hashchange', render);

  const footer = () => `<footer class="foot">Stan prawny i opłaty: ${esc(META.stan)} Kompendium ma charakter informacyjny i nie zastępuje tekstów aktów prawnych ani rozstrzygnięć organów nadzoru górniczego i administracji geologicznej. Źródła: ${ext(LINKS.wugKwalifikacje, 'WUG – kwalifikacje górnicze')}, ${ext(LINKS.isapPgg, 'Pgg (Dz.U. 2026 poz. 69)')}, ${ext(LINKS.isapRozp992, 'rozp. Dz.U. 2024 poz. 992')}, ${ext(LINKS.isapGeol, 'rozp. Dz.U. 2026 poz. 249')}.</footer>`;

  // ═══════════════ START ═══════════════
  route('start', () => {
    const goal = store.get('goal', null);
    const goalQ = goal && Q(goal);
    const done = store.get('steps', {});
    const doneN = PROCEDURE.filter((s) => done[s.id]).length;
    const qs = store.get('qs', {});
    const known = Object.values(qs).filter((v) => v.s === 'k').length;
    main.innerHTML = `
      <section class="card hero">
        <h1>Kwalifikacje górnicze, wiertnicze i geologiczne – od wniosku do świadectwa</h1>
        <p>Wymagania z rozporządzenia z 2024 r., procedura przed dyrektorem OUG i Prezesem WUG, dokumenty, opłaty, akty prawne i ponad 1000 pytań egzaminacyjnych WUG – w jednym miejscu, także offline.</p>
        <div class="btns">
          <a class="btn primary" href="#/kreator">Znajdź swoją kwalifikację</a>
          <a class="btn" href="#/procedura">Procedura krok po kroku</a>
          <a class="btn" href="#/pytania">Ćwicz pytania</a>
        </div>
      </section>

      ${goalQ ? `
      <section class="card" style="margin-top:14px">
        <div class="section-head"><h2 style="margin-top:0">Twój cel</h2><a href="#/k/${goalQ.id}">szczegóły →</a></div>
        <p><strong>${esc(goalQ.title)}</strong> ${organChip(goalQ.organ)}</p>
        <div class="stats">
          <div class="stat"><b>${doneN}/${PROCEDURE.length}</b><span>kroków procedury</span></div>
          <div class="stat"><b>${known}</b><span>pytań oznaczonych „umiem”</span></div>
          <div class="stat"><b>${goalQ.form ? 'nr ' + FORMS[goalQ.form].nr : '—'}</b><span>formularz wniosku</span></div>
        </div>
        <div class="progress" style="margin-top:12px"><i style="width:${Math.round(doneN / PROCEDURE.length * 100)}%"></i></div>
      </section>` : ''}

      <div class="note warn" style="margin-top:14px">
        <p><strong>Zmiana 2026:</strong> od 17 marca 2026 r. obowiązuje nowe rozporządzenie Ministra Klimatu i Środowiska w sprawie kwalifikacji w zakresie geologii (Dz.U. 2026 poz. 249). Zestawienie „Wymagana wiedza” na stronie WUG nadal wymienia uchylone rozporządzenie z 2023 r. – w aplikacji oznaczono akty uchylone.</p>
      </div>

      <h2>Obszary</h2>
      <div class="grid cols-3">
        ${GROUPS.map((g) => {
          const n = QUALS.filter((q) => q.group === g.id).length;
          return `<a class="card tile" href="#/kwalifikacje?g=${g.id}"><span class="k">${n} ${n === 1 ? 'pozycja' : n < 5 ? 'pozycje' : 'pozycji'}</span><strong>${esc(g.name)}</strong><p>${esc(g.desc)}</p></a>`;
        }).join('')}
      </div>

      <h2>Najważniejsze w skrócie</h2>
      <div class="grid cols-2">
        <div class="card">
          <h3>Kto stwierdza kwalifikacje?</h3>
          <ul>
            <li><strong>Dyrektor OUG</strong> – dozór, wyższy dozór i kierownicy działów we wszystkich zakładach; kierownik ruchu w odkrywkach i otworowych (art. 58 ust. 1). Egzamin <em>ustny</em>.</li>
            <li><strong>Prezes WUG</strong> – kierownik ruchu zakładów podziemnych, mierniczy, geolog i geofizyk górniczy, kierownictwo ratownictwa, składowanie CO₂ (art. 58 ust. 2). Egzamin <em>pisemny (20 pytań, próg 75%) + ustny</em>.</li>
            <li><strong>Minister KiŚ / marszałek</strong> – kwalifikacje geologiczne kat. I–IX / XIII (art. 51).</li>
          </ul>
        </div>
        <div class="card">
          <h3>Opłaty ${FEES.rok}</h3>
          <dl class="kv">
            <dt>Egzamin</dt><dd>${FEES.egzamin}</dd>
            <dt>Świadectwo</dt><dd>${FEES.swiadectwo}</dd>
            <dt>Uznanie kwalifikacji</dt><dd>${FEES.uznanie}</dd>
            <dt>Rachunek</dt><dd style="font-family:var(--mono);font-size:.88rem">${FEES.konto}</dd>
          </dl>
          <p class="muted" style="margin-top:8px">Dowód wpłaty przekazujesz komisji przed egzaminem – nie dołączasz go do wniosku.</p>
        </div>
      </div>

      <h2>Narzędzia</h2>
      <div class="grid cols-3">
        <a class="card tile" href="#/procedura?t=dok"><span class="k">Lista kontrolna</span><strong>Dokumenty do wniosku</strong><p>Odhaczaj, co już masz. Formularze WUG 1–6.</p></a>
        <a class="card tile" href="#/procedura?t=kalk"><span class="k">Kalkulator</span><strong>Kiedy skończę praktykę?</strong><p>Data końca wymaganej praktyki zawodowej.</p></a>
        <a class="card tile" href="#/prawo?t=tab"><span class="k">Źródło</span><strong>Tabele rozporządzenia</strong><p>46 tabel wymagań z odnośnikiem do strony PDF.</p></a>
        <a class="card tile" href="#/pytania?b=geolog"><span class="k">553 pytania</span><strong>Geolog górniczy</strong><p>Fiszki i symulacja egzaminu pisemnego.</p></a>
        <a class="card tile" href="#/pytania?b=mierniczy"><span class="k">467 pytań</span><strong>Mierniczy górniczy</strong><p>Fiszki i symulacja egzaminu pisemnego.</p></a>
        <a class="card tile" href="#/slownik"><span class="k">Słownik</span><strong>Pojęcia i zakres wiedzy</strong><p>Dozór, wyższy dozór, art. 2 ust. 1, art. 86…</p></a>
      </div>
      ${footer()}`;
  });

  // ═══════════════ LISTA KWALIFIKACJI ═══════════════
  route('kwalifikacje', (_, params) => {
    const g = params.get('g');
    const groups = g ? GROUPS.filter((x) => x.id === g) : GROUPS;
    main.innerHTML = `
      <div class="crumbs"><a href="#/">Start</a> / Kwalifikacje</div>
      <h1>Katalog kwalifikacji</h1>
      <p class="lead">Wybierz kwalifikację, aby zobaczyć organ, wymagane wykształcenie i praktykę, formularz, opłaty i zakres wiedzy.</p>
      <div class="chips" role="group" aria-label="Filtr obszaru">
        <a class="chip ${!g ? 'accent' : ''}" href="#/kwalifikacje">Wszystkie</a>
        ${GROUPS.map((x) => `<a class="chip ${g === x.id ? 'accent' : ''}" href="#/kwalifikacje?g=${x.id}">${esc(x.name)}</a>`).join('')}
      </div>
      ${groups.map((gr) => `
        <div class="group-h"><h2>${esc(gr.name)}</h2><span class="muted">${esc(gr.desc)}</span></div>
        <div class="qlist">
          ${QUALS.filter((q) => q.group === gr.id).map((q) => `
            <a class="card qitem" href="#/k/${q.id}">
              <div><strong>${esc(q.title)}</strong>
                <div class="meta" style="margin-top:6px">${organChip(q.organ)}<span class="chip">${esc(q.level)}</span>${q.form ? `<span class="chip">formularz ${FORMS[q.form].nr}</span>` : ''}${q.questions ? '<span class="chip ok">pytania</span>' : ''}</div>
              </div>
              <span class="arrow" aria-hidden="true">›</span>
            </a>`).join('')}
        </div>`).join('')}
      ${footer()}`;
  });

  // ═══════════════ SZCZEGÓŁY ═══════════════
  route('k', ([id]) => {
    const q = Q(id);
    if (!q) { main.innerHTML = '<p>Nie znaleziono kwalifikacji.</p>'; return; }
    const o = organ(q.organ);
    const isGoal = store.get('goal', null) === q.id;
    const acts = ACTS.filter((a) => a.tags.includes('all') || a.tags.some((t) => q.knowledge.includes(t)));
    const tables = (q.tables || []).map(tableById).filter(Boolean);
    main.innerHTML = `
      <div class="crumbs"><a href="#/">Start</a> / <a href="#/kwalifikacje?g=${q.group}">${esc(GROUPS.find((g) => g.id === q.group).name)}</a></div>
      <h1>${esc(q.title)}</h1>
      <div class="chips">${organChip(q.organ)}<span class="chip">${esc(q.level)}</span><span class="chip">${esc(q.basis)}</span></div>
      <div class="btns" style="margin-bottom:16px">
        <button class="btn ${isGoal ? '' : 'primary'}" id="goalBtn" type="button">${isGoal ? '✓ To mój cel' : 'Ustaw jako mój cel'}</button>
        ${q.form ? `<a class="btn" href="${esc(FORMS[q.form].url)}" target="_blank" rel="noopener">Formularz wniosku nr ${FORMS[q.form].nr} (${FORMS[q.form].fmt})</a>` : ''}
        ${q.questions ? `<a class="btn" href="#/pytania?b=${q.questions}">Ćwicz pytania</a>` : ''}
      </div>

      <section class="card">
        <p>${esc(q.intro)}</p>
        <dl class="kv">
          <dt>Organ</dt><dd>${esc(o.name)}</dd>
          <dt>Egzamin</dt><dd>${esc(o.exam)}</dd>
          <dt>Podstawa</dt><dd>${esc(q.basis)}</dd>
          ${q.form ? `<dt>Formularz</dt><dd>${ext(FORMS[q.form].url, FORMS[q.form].title)}</dd>` : ''}
        </dl>
      </section>

      ${q.specs && q.specs.length ? `<h2>${q.group === 'geologia' && q.id.endsWith('XIII') ? 'Organy (marszałkowie)' : q.group === 'geologia' ? 'Kategorie' : q.id === 'specjalistyczne' ? 'Czynności' : 'Specjalności / działy'}</h2><ul class="${q.specs.length > 6 ? 'cols' : ''}">${q.specs.map((s) => `<li>${esc(s)}</li>`).join('')}</ul>` : ''}

      ${q.paths && q.paths.length ? `
        <h2>Wymagane wykształcenie i praktyka</h2>
        ${q.pathsTitle ? `<p class="muted">${esc(q.pathsTitle)}</p>` : ''}
        <div class="table-wrap"><table class="stack">
          <thead><tr><th>Tytuł / poziom</th><th>Wykształcenie</th><th>Praktyka</th></tr></thead>
          <tbody>${q.paths.map((p) => `<tr><td data-l="Tytuł / poziom"><strong>${esc(p.who)}</strong></td><td data-l="Wykształcenie">${esc(p.edu)}</td><td data-l="Praktyka" class="time">${esc(p.time)}</td></tr>`).join('')}</tbody>
        </table></div>` : ''}
      ${q.practice && q.practice !== '—' ? `<p style="margin-top:10px"><strong>Rodzaj praktyki:</strong> ${esc(q.practice)}</p>` : ''}
      ${q.patternNote ? `<div class="note">${esc(q.patternNote)}</div>` : ''}
      <div class="note accent"><p>Wymagany jest <strong>jeden</strong> z wariantów (jeden tytuł, jeden zakres studiów). Zakres studiów potwierdzasz nazwą kierunku, specjalności albo wykazem przedmiotów / efektów uczenia się w suplemencie (${artLink(57, 'art. 57 Pgg')}). Organ może uznać praktykę odbytą w zakładach działających inną metodą (${artLink(55, 'art. 55 ust. 2a Pgg')}).</p></div>

      ${tables.length ? `
        <h2>Źródło – tabele rozporządzenia</h2>
        <p class="muted">Rozporządzenie Ministra Przemysłu z 25.06.2024 r. (Dz.U. 2024 poz. 992). Linki otwierają właściwą stronę PDF (dostępny offline).</p>
        <ul>${tables.map((t) => `<li><a href="${pdfPage('rozp992', t.p)}" target="_blank" rel="noopener">Tabela ${esc(t.id)} – ${esc(t.t)}</a> <span class="muted">(str. ${t.p}${t.r ? `; praktyka ${fmtMonths(t.r[0])}–${fmtMonths(t.r[1])}` : ''})</span></li>`).join('')}</ul>` : ''}
      ${q.group === 'geologia' ? `<p>${ext(META.docs.geol, 'Rozporządzenie MKiŚ z 11.02.2026 r. (PDF, offline)')} · ${ext(LINKS.isapGeol, 'ISAP')}</p>` : ''}

      ${q.equivalents && q.equivalents.length ? `<h2>Uprawnienia „w pakiecie” i równoważności</h2><ul>${q.equivalents.map((e) => `<li>${esc(e)}</li>`).join('')}</ul>` : ''}

      <h2>Procedura</h2>
      ${q.group === 'geologia'
        ? `<ul>${PROCEDURE_GEO.map((s) => `<li><strong>${esc(s.title)}:</strong> ${esc(s.body)}</li>`).join('')}</ul>`
        : q.organ === 'PRAC'
          ? '<p>Brak postępowania przed organem nadzoru górniczego – kwalifikacje weryfikuje pracodawca (zaświadczenie w aktach osobowych).</p>'
          : `<p>${q.organ === 'WUG' ? 'Wniosek składasz do Prezesa WUG (Katowice).' : 'Wniosek składasz do dyrektora okręgowego urzędu górniczego właściwego dla zakładu.'} ${esc(o.exam)}</p><a class="btn small" href="#/procedura">Pełna procedura i lista dokumentów →</a>`}

      ${q.organ !== 'PRAC' ? `<h2>Opłaty ${FEES.rok}</h2>
        ${q.group === 'geologia' ? '<p>Opłaty wg art. 66 Pgg – stawki ogłasza minister właściwy do spraw środowiska (sprawdź w BIP organu).</p>'
          : q.id === 'uznawanie' ? `<p>Postępowanie o uznanie kwalifikacji: <strong>${FEES.uznanie}</strong> (${esc(FEES.uznanieOpis)}).</p>`
          : `<p>Egzamin: <strong>${FEES.egzamin}</strong> · świadectwo: <strong>${FEES.swiadectwo}</strong> · rachunek ${esc(FEES.bank)}: <span style="font-family:var(--mono)">${FEES.konto}</span></p>`}` : ''}

      ${q.id === 'pz-kruchu' ? `<h2>Wybrane zagadnienia egzaminacyjne (WUG)</h2><details><summary>Z ustawy Pgg (${TOPICS.ustawa.length})</summary><ul class="cols">${TOPICS.ustawa.map((t) => `<li>${esc(t)}</li>`).join('')}</ul></details><details><summary>Z rozporządzeń wykonawczych (${TOPICS.rozporzadzenia.length})</summary><ul class="cols">${TOPICS.rozporzadzenia.map((t) => `<li>${esc(t)}</li>`).join('')}</ul></details>` : ''}
      ${q.ratTopics ? `<h2>Zakres wiedzy (art. 54 pkt 2 Pgg)</h2><ul>${TOPICS.ratownictwo.map((t) => `<li>${esc(t)}</li>`).join('')}</ul>` : ''}

      <h2>Wymagana wiedza – akty prawne</h2>
      <p class="muted">Wybór z zestawienia WUG dopasowany do rodzaju kwalifikacji. Od kandydata wymaga się znajomości przepisów dotyczących czynności, o które się ubiega.</p>
      <ul>${acts.map((a) => `<li>${a.url ? ext(a.url, a.title) : esc(a.title)}${a.addr ? ` <span class="muted">(${esc(a.addr)})</span>` : ''}${/uchylon/.test(a.status || '') ? ' <span class="chip warn">uchylony</span>' : ''}</li>`).join('')}</ul>
      <a class="btn small" href="#/prawo">Wszystkie akty prawne →</a>
      ${footer()}`;
    $('#goalBtn').addEventListener('click', () => {
      const cur = store.get('goal', null);
      store.set('goal', cur === q.id ? null : q.id);
      toast(cur === q.id ? 'Usunięto cel' : 'Ustawiono jako Twój cel');
      render();
    });
  });

  // ═══════════════ KREATOR ═══════════════
  const WIZ = {
    start: { q: 'Czego dotyczą czynności, które chcesz wykonywać?', opts: [
      { l: 'Kierownictwo lub dozór ruchu zakładu', d: 'dozór, wyższy dozór, kierownik działu, kierownik ruchu', go: 'zaklad' },
      { l: 'Mierniczy górniczy', d: 'obsługa miernicza zakładu', res: 'mierniczy' },
      { l: 'Geolog górniczy', d: 'obsługa geologiczna zakładu górniczego', res: 'geolog-gorn' },
      { l: 'Geofizyk górniczy', d: 'geofizyka w podziemnych zakładach', res: 'geofizyk' },
      { l: 'Prace geologiczne', d: 'projekty, dokumentacje, hydrogeologia, geotechnika, dozór geologiczny', go: 'geo' },
      { l: 'Ratownictwo górnicze', d: 'kierownictwo w podmiotach ratowniczych', res: 'ratownictwo' },
      { l: 'Czynności specjalistyczne', d: 'strzałowy, maszynista, operator, elektromonter…', res: 'specjalistyczne' },
      { l: 'Kwalifikacje z zagranicy', d: 'UE, EFTA, Szwajcaria, Ukraina', res: 'uznawanie' }
    ] },
    zaklad: { q: 'W jakim rodzaju zakładu?', opts: [
      { l: 'Podziemny zakład górniczy', d: 'kopalnie węgla, rud, soli; także tunele, kopalnie turystyczne (art. 2 ust. 1)', go: 'poz', set: 'pz' },
      { l: 'Odkrywkowy zakład górniczy', d: 'węgiel brunatny, kruszywa, kamieniołomy', go: 'poz', set: 'od' },
      { l: 'Otworowy zakład górniczy', d: 'ropa, gaz, sól otworowo, wody lecznicze i termalne, PMG', go: 'poz', set: 'ot' },
      { l: 'Zakład wykonujący roboty geologiczne', d: 'wiercenia poszukiwawcze i rozpoznawcze (art. 86 Pgg)', go: 'poz', set: 'rg' },
      { l: 'Specjalność budowlana lub ochrona środowiska', d: 'w dowolnym rodzaju zakładu', res: 'bo' }
    ] },
    poz: { q: 'Na jakim szczeblu?', opts: [
      { l: 'Dozór ruchu', d: 'np. sztygar zmianowy, nadgórnik, mistrz wiertniczy', lvl: 'dozor' },
      { l: 'Wyższy dozór ruchu', d: 'np. sztygar oddziałowy, kierownik robót', lvl: 'wdozor' },
      { l: 'Kierownik działu ruchu (lub zastępca)', d: 'górniczy, energomechaniczny, wentylacji, wiertniczy…', lvl: 'kdzial' },
      { l: 'Kierownik ruchu zakładu (lub zastępca)', d: 'najwyższa funkcja w ruchu zakładu', lvl: 'kruchu' }
    ] },
    geo: { q: 'Jakie prace geologiczne?', opts: [
      { l: 'Projektowanie i dokumentowanie (kat. I–IX)', d: 'złoża, hydrogeologia, geotechnika, kartografia, sejsmika', res: 'geologia-I-IX' },
      { l: 'Dozór geologiczny / kierowanie robotami w terenie (kat. XIII)', d: 'wiercenia do 100 m, bez środków strzałowych', res: 'geologia-XIII' }
    ] }
  };
  route('kreator', () => {
    let state = { step: 'start', trail: [], set: null };
    const resolve = (set, lvl) => ({ pz: 'pz-', od: 'od-', ot: 'ot-', rg: 'ot-' }[set] + lvl).replace('ot-dozor', set === 'rg' ? 'ot-wiert-dozor' : 'ot-dozor');
    function draw(resultId) {
      const res = resultId && Q(resultId);
      main.innerHTML = `
        <div class="crumbs"><a href="#/">Start</a> / Kreator</div>
        <h1>Która kwalifikacja jest dla Ciebie?</h1>
        <div class="wiz-trail">${state.trail.map((t) => `<span class="chip">${esc(t)}</span>`).join('')}</div>
        <section class="card wizard">
          ${res ? `
            <p class="muted">Wynik</p>
            <h2 style="margin-top:0">${esc(res.title)}</h2>
            <dl class="kv">
              <dt>Organ</dt><dd>${esc(organ(res.organ).name)}</dd>
              <dt>Egzamin</dt><dd>${esc(organ(res.organ).exam)}</dd>
              ${res.form ? `<dt>Formularz</dt><dd>nr ${FORMS[res.form].nr} – ${esc(FORMS[res.form].title)}</dd>` : ''}
              <dt>Podstawa</dt><dd>${esc(res.basis)}</dd>
            </dl>
            ${resultId === 'pz-kruchu' ? '' : resultId === 'ot-kruchu' ? '<div class="note">Kierownik ruchu zakładu podziemnego składowania CO₂ – kwalifikacje stwierdza Prezes WUG.</div>' : ''}
            <div class="btns" style="margin-top:14px">
              <a class="btn primary" href="#/k/${res.id}">Zobacz wymagania</a>
              <button class="btn" id="wGoal" type="button">Ustaw jako mój cel</button>
              <button class="btn" id="wReset" type="button">Zacznij od nowa</button>
            </div>`
          : `
            <h2 style="margin-top:0">${esc(WIZ[state.step].q)}</h2>
            <div class="opts">${WIZ[state.step].opts.map((o, i) => `<button class="opt" type="button" data-i="${i}"><strong>${esc(o.l)}</strong><span>${esc(o.d)}</span></button>`).join('')}</div>
            ${state.trail.length ? '<div class="btns" style="margin-top:14px"><button class="btn small" id="wReset" type="button">← Od początku</button></div>' : ''}`}
        </section>
        ${footer()}`;
      $$('.opt').forEach((b) => b.addEventListener('click', () => {
        const o = WIZ[state.step].opts[+b.dataset.i];
        state.trail.push(o.l);
        if (o.set) state.set = o.set;
        if (o.res) return draw(o.res);
        if (o.lvl) return draw(resolve(state.set, o.lvl));
        state.step = o.go; draw();
      }));
      const r = $('#wReset'); if (r) r.addEventListener('click', () => { state = { step: 'start', trail: [], set: null }; draw(); });
      const g = $('#wGoal'); if (g) g.addEventListener('click', () => { store.set('goal', resultId); toast('Ustawiono jako Twój cel'); });
    }
    draw();
  });

  // ═══════════════ PROCEDURA / DOKUMENTY / KALKULATOR ═══════════════
  route('procedura', (_, params) => {
    const tab = params.get('t') || 'kroki';
    const tabs = [['kroki', 'Procedura'], ['dok', 'Dokumenty i formularze'], ['oplaty', 'Opłaty'], ['kalk', 'Kalkulator praktyki'], ['geo', 'Geologia (kat. I–XIII)'], ['oug', 'Okręgowe urzędy']];
    main.innerHTML = `
      <div class="crumbs"><a href="#/">Start</a> / Procedura</div>
      <h1>Od wniosku do świadectwa</h1>
      <div class="chips" role="tablist">${tabs.map(([k, l]) => `<a class="chip ${tab === k ? 'accent' : ''}" role="tab" aria-selected="${tab === k}" href="#/procedura?t=${k}">${l}</a>`).join('')}</div>
      <div id="pv"></div>
      ${footer()}`;
    const pv = $('#pv');

    if (tab === 'kroki') {
      const done = store.get('steps', {});
      const n = PROCEDURE.filter((s) => done[s.id]).length;
      pv.innerHTML = `
        <p class="lead">Postępowanie w sprawie stwierdzenia kwalifikacji w zakresie górnictwa i ratownictwa górniczego (dyrektor OUG / Prezes WUG). Zaznaczaj ukończone kroki – postęp zapisuje się na tym urządzeniu.</p>
        <div class="progress" style="margin-bottom:6px"><i style="width:${Math.round(n / PROCEDURE.length * 100)}%"></i></div>
        <p class="muted">${n} z ${PROCEDURE.length} kroków</p>
        <ol class="steps">${PROCEDURE.map((s, i) => `
          <li class="step card ${done[s.id] ? 'done' : ''}">
            <span class="num">${done[s.id] ? '✓' : i + 1}</span>
            <div class="body">
              <h3>${esc(s.title)}</h3>
              <p>${esc(s.body)}</p>
              <div style="display:flex;justify-content:space-between;gap:10px;flex-wrap:wrap;align-items:center">
                <span class="law">${esc(s.law)}</span>
                <label class="check"><input type="checkbox" data-s="${s.id}" ${done[s.id] ? 'checked' : ''}> zrobione</label>
              </div>
            </div>
          </li>`).join('')}</ol>
        <div class="btns" style="margin-top:12px"><button class="btn small" id="resetSteps" type="button">Wyczyść postęp</button></div>`;
      $$('input[data-s]', pv).forEach((c) => c.addEventListener('change', () => { const d = store.get('steps', {}); d[c.dataset.s] = c.checked; store.set('steps', d); render(); }));
      $('#resetSteps').addEventListener('click', () => { store.set('steps', {}); render(); });
    }

    if (tab === 'dok') {
      const have = store.get('docs', {});
      pv.innerHTML = `
        <h2 style="margin-top:0">Lista kontrolna</h2>
        <div class="card"><ul style="list-style:none;padding:0;margin:0;display:grid;gap:10px">
          ${CHECKLIST.map((c) => `<li><label class="check" style="align-items:flex-start"><input type="checkbox" data-c="${c.id}" ${have[c.id] ? 'checked' : ''}><span>${esc(c.t)} ${c.req ? '<span class="chip warn">wymagane</span>' : '<span class="chip">jeśli dotyczy</span>'}</span></label></li>`).join('')}
        </ul></div>
        <div class="note"><p>Zamiast uwierzytelnionych kopii możesz złożyć oryginały – zostaną zwrócone najpóźniej w dniu egzaminu. Kopie uwierzytelnia np. notariusz, a w przypadku dokumentów pracowniczych – pracodawca lub organ.</p></div>
        <h2>Formularze wniosków (WUG)</h2>
        <div class="qlist">${Object.values(FORMS).map((f) => `<a class="card qitem" href="${esc(f.url)}" target="_blank" rel="noopener"><div><strong>${f.nr}. ${esc(f.title)}</strong><div class="meta" style="margin-top:6px"><span class="chip">${f.fmt}</span></div></div><span class="arrow">↗</span></a>`).join('')}</div>
        <p class="muted" style="margin-top:10px">Formularze pobierane są ze strony WUG (wymagany internet). Aktualne wersje: ${ext(LINKS.wugGornictwo, 'gov.pl/web/wug')}.</p>
        <h2>Co musi zawierać wniosek (art. 61 ust. 2 Pgg)</h2>
        <ol><li>imię i nazwisko,</li><li>numer PESEL (jeśli posiadasz),</li><li>seria i numer dowodu osobistego lub innego dokumentu tożsamości,</li><li>adres zamieszkania,</li><li>kwalifikacje, o które się ubiegasz – z uwzględnieniem art. 58 ust. 1 lub 2 Pgg,</li><li>wykształcenie,</li><li>gdy wymagane: studia podyplomowe, tytuł zawodowy / kwalifikacje w zawodzie / uprawnienia zawodowe, egzaminy uzupełniające,</li><li>opis doświadczenia zawodowego, ze szczególnym uwzględnieniem kwalifikacji, o które się ubiegasz.</li></ol>
        <h3>Wskazówki do opisu doświadczenia</h3>
        <ul><li>Podaj okresy (od–do), zakład, rodzaj zakładu (metoda: podziemna, odkrywkowa, otworowa), dział ruchu, specjalność i stanowisko.</li><li>Opisz czynności, a nie tylko nazwy stanowisk – organ ocenia „rodzaj wykonywanych czynności” z tabel rozporządzenia.</li><li>Zaznacz praktykę „pod ziemią”, w dozorze / wyższym dozorze / kierownictwie działu – tak jak w kolumnie „Rodzaj wykonywanych czynności”.</li><li>Zsumuj okresy i porównaj z wymaganym czasem praktyki (kalkulator w zakładce obok).</li></ul>`;
      $$('input[data-c]', pv).forEach((c) => c.addEventListener('change', () => { const d = store.get('docs', {}); d[c.dataset.c] = c.checked; store.set('docs', d); }));
    }

    if (tab === 'oplaty') {
      pv.innerHTML = `
        <div class="grid cols-2">
          <div class="card"><h3>Stwierdzenie kwalifikacji (górnictwo i ratownictwo) – ${FEES.rok}</h3>
            <dl class="kv"><dt>Opłata egzaminacyjna</dt><dd>${FEES.egzamin}</dd><dt>Egzamin ponowny</dt><dd>${FEES.egzaminPonowny}</dd><dt>Wydanie świadectwa</dt><dd>${FEES.swiadectwo}</dd></dl></div>
          <div class="card"><h3>Uznanie kwalifikacji zagranicznych – ${FEES.rok}</h3>
            <dl class="kv"><dt>Opłata</dt><dd>${FEES.uznanie}</dd><dt>Wyliczenie</dt><dd>${esc(FEES.uznanieOpis)}</dd></dl></div>
        </div>
        <div class="card" style="margin-top:14px"><h3>Jak zapłacić</h3>
          <dl class="kv"><dt>Odbiorca</dt><dd>${esc(FEES.odbiorca)}</dd><dt>Bank</dt><dd>${esc(FEES.bank)}</dd><dt>Rachunek</dt><dd style="font-family:var(--mono)">${FEES.konto} <button class="btn small" id="copyAcc" type="button">Kopiuj</button></dd></dl>
          <p style="margin-top:10px">albo gotówką w kasie urzędu, przy którym działa komisja egzaminacyjna.</p>
          <h3>Tytuł przelewu – przykłady</h3>
          <ul>${FEES.tytulPrzyklady.map((t) => `<li>${esc(t)}</li>`).join('')}</ul></div>
        <div class="note"><p>Stawki zmieniają się co roku (waloryzacja wskaźnikiem cen – ${artLink(66, 'art. 66 ust. 4–5 Pgg')}); podstawa na ${FEES.rok} r.: ${esc(FEES.podstawa)}. Gdy egzamin wyznaczono na kolejny rok – płacisz stawkę obowiązującą w dniu egzaminu. Opłata nie podlega zwrotowi, jeśli nie stawisz się na egzamin bez powiadomienia organu.</p></div>`;
      $('#copyAcc').addEventListener('click', () => { navigator.clipboard && navigator.clipboard.writeText(FEES.konto.replace(/\s/g, '')).then(() => toast('Skopiowano numer rachunku'), () => toast('Nie udało się skopiować')); });
    }

    if (tab === 'kalk') {
      const saved = store.get('calc', { start: '', months: 12, periods: [] });
      pv.innerHTML = `
        <p class="lead">Policz, kiedy osiągniesz wymagany okres praktyki, albo zsumuj kilka okresów zatrudnienia.</p>
        <div class="grid cols-2">
          <div class="card">
            <h3>Data osiągnięcia praktyki</h3>
            <label>Początek praktyki<br><input type="date" id="cStart" value="${esc(saved.start)}"></label>
            <p style="margin:12px 0 6px">Wymagany okres</p>
            <div class="chips">${[3, 6, 9, 12, 18, 24, 30, 36, 48, 60].map((m) => `<button type="button" class="chip" data-m="${m}" aria-pressed="${saved.months === m}">${fmtMonths(m)}</button>`).join('')}</div>
            <label>lub miesięcy: <input type="number" id="cMonths" min="1" max="120" value="${saved.months}" style="width:90px"></label>
            <div class="note ok" id="cOut" style="margin-top:14px"></div>
          </div>
          <div class="card">
            <h3>Suma okresów praktyki</h3>
            <div id="per"></div>
            <div class="btns" style="margin-top:8px"><button class="btn small" id="addPer" type="button">+ Dodaj okres</button></div>
            <div class="note" id="sumOut" style="margin-top:14px"></div>
          </div>
        </div>
        <p class="muted" style="margin-top:10px">Kalkulator liczy miesiące kalendarzowe. O zaliczeniu praktyki (rodzaj czynności, dział, specjalność) decyduje organ.</p>`;
      const save = () => store.set('calc', saved);
      const calc = () => {
        const out = $('#cOut');
        if (!saved.start) { out.textContent = 'Wybierz datę rozpoczęcia praktyki.'; return; }
        const d = new Date(saved.start + 'T00:00:00'); const end = new Date(d); end.setMonth(end.getMonth() + saved.months);
        const now = new Date(); const left = Math.ceil((end - now) / 86400000);
        out.innerHTML = `Wymagane ${fmtMonths(saved.months)} upłynie <strong>${end.toLocaleDateString('pl-PL', { day: 'numeric', month: 'long', year: 'numeric' })}</strong>. ${left > 0 ? `Pozostało ${left} dni.` : 'Okres został już osiągnięty.'}`;
      };
      $('#cStart').addEventListener('change', (e) => { saved.start = e.target.value; save(); calc(); });
      $('#cMonths').addEventListener('input', (e) => { saved.months = Math.max(1, +e.target.value || 1); save(); calc(); $$('[data-m]', pv).forEach((b) => b.setAttribute('aria-pressed', +b.dataset.m === saved.months)); });
      $$('[data-m]', pv).forEach((b) => b.addEventListener('click', () => { saved.months = +b.dataset.m; $('#cMonths').value = saved.months; save(); calc(); $$('[data-m]', pv).forEach((x) => x.setAttribute('aria-pressed', x === b)); }));
      const drawPer = () => {
        $('#per').innerHTML = saved.periods.map((p, i) => `<div style="display:flex;gap:6px;align-items:center;flex-wrap:wrap;margin-bottom:6px"><input type="date" data-pi="${i}" data-k="a" value="${esc(p.a)}" aria-label="Od"> – <input type="date" data-pi="${i}" data-k="b" value="${esc(p.b)}" aria-label="Do"><button class="btn small" type="button" data-del="${i}" aria-label="Usuń">✕</button></div>`).join('') || '<p class="muted">Dodaj okresy zatrudnienia (od–do).</p>';
        $$('[data-pi]', pv).forEach((inp) => inp.addEventListener('change', () => { saved.periods[+inp.dataset.pi][inp.dataset.k] = inp.value; save(); sum(); }));
        $$('[data-del]', pv).forEach((b) => b.addEventListener('click', () => { saved.periods.splice(+b.dataset.del, 1); save(); drawPer(); sum(); }));
      };
      const sum = () => {
        let days = 0;
        saved.periods.forEach((p) => { if (p.a && p.b) { const d = (new Date(p.b) - new Date(p.a)) / 86400000 + 1; if (d > 0) days += d; } });
        const months = days / 30.4375;
        $('#sumOut').innerHTML = `Razem: <strong>${Math.floor(months / 12)} lat ${Math.floor(months % 12)} mies.</strong> (${Math.round(days)} dni ≈ ${months.toFixed(1)} mies.)`;
      };
      $('#addPer').addEventListener('click', () => { saved.periods.push({ a: '', b: '' }); save(); drawPer(); sum(); });
      calc(); drawPer(); sum();
    }

    if (tab === 'geo') {
      pv.innerHTML = `
        <p class="lead">Kwalifikacje w zawodzie geolog (art. 50–52 Pgg) – odrębne postępowanie przed administracją geologiczną, nie przed urzędami górniczymi.</p>
        <ol class="steps">${PROCEDURE_GEO.map((s, i) => `<li class="step card"><span class="num">${i + 1}</span><div class="body"><h3>${esc(s.title)}</h3><p>${esc(s.body)}</p></div></li>`).join('')}</ol>
        <div class="btns" style="margin-top:12px"><a class="btn" href="#/k/geologia-I-IX">Kategorie I–IX</a><a class="btn" href="#/k/geologia-XIII">Kategoria XIII</a><a class="btn" href="${esc(LINKS.mkisGeolog)}" target="_blank" rel="noopener">Ministerstwo KiŚ ↗</a></div>`;
    }

    if (tab === 'oug') {
      pv.innerHTML = `
        <p class="lead">Wniosek o kwalifikacje z art. 58 ust. 1 Pgg składasz do dyrektora OUG. Właściwość miejscową określa rozporządzenie MAP z 1.03.2022 r. (Dz.U. 2022 poz. 525) – w praktyce właściwy jest urząd nadzorujący zakład, w którym pracujesz. W razie wątpliwości zapytaj urząd.</p>
        <div class="table-wrap"><table class="stack"><thead><tr><th>Urząd</th><th>Siedziba</th><th>Obszar</th></tr></thead><tbody>
          ${OUG.map((o) => `<tr><td data-l="Urząd"><strong>${esc(o.n)}</strong></td><td data-l="Siedziba">${esc(o.s)}</td><td data-l="Obszar">${esc(o.w)}</td></tr>`).join('')}
        </tbody></table></div>
        <p style="margin-top:10px">${ext(LINKS.wugOug, 'Dane kontaktowe OUG – gov.pl/web/wug')} · ${ext(META.docs.oug, 'Rozporządzenie (PDF, offline)')}</p>
        <div class="card" style="margin-top:14px"><h3>Wyższy Urząd Górniczy</h3><p>ul. Poniatowskiego 31, 40-055 Katowice · tel. 32 736 17 00 · pn–pt 7:00–15:00</p></div>`;
    }
  });

  // ═══════════════ PRAWO ═══════════════
  const ART_SUMMARY = [
    [50, 'Kategorie kwalifikacji w zawodzie geolog (I–IX, XIII).'],
    [51, 'Kto wydaje świadectwa geologiczne: minister (I–IX), marszałkowie (XIII).'],
    [52, 'Wykształcenie i praktyka dla kwalifikacji geologicznych; co jest praktyką.'],
    [53, 'Kto musi mieć kwalifikacje górnicze: kierownictwo i dozór ruchu, mierniczy, geolog, geofizyk, ratownictwo, czynności specjalistyczne.'],
    [54, 'Przygotowanie zawodowe: znajomość przepisów i zagadnień + wykształcenie / podyplomowe / egzaminy uzupełniające.'],
    [55, 'Doświadczenie zawodowe: praktyka w ruchu, miernicza, geologiczna, geofizyczna, ratownicza; ust. 2a – uznanie innej praktyki.'],
    [56, 'Wymagania dla czynności specjalistycznych: szkoła, praktyka, kursy, badania, wiek.'],
    [57, 'Jak potwierdza się zakres studiów; egzaminy uzupełniające.'],
    [58, 'Który organ stwierdza jakie kwalifikacje: ust. 1 – dyrektor OUG, ust. 2 – Prezes WUG; kierownicy działów mierniczego i geologicznego.'],
    [59, 'Kwalifikacje „w pakiecie” (zastępcy; mierniczy, geolog, geofizyk).'],
    [60, 'Dodatkowe uprawnienia wynikające z posiadanych kwalifikacji (np. odkrywki na koncesji starosty).'],
    [61, 'Wniosek i załączniki.'],
    [62, 'Dopuszczenie do egzaminu albo decyzja odmowna.'],
    [63, 'Komisje egzaminacyjne; zawiadomienie 14 dni (górnictwo) / BIP 30 dni (geologia); dowód opłaty.'],
    [64, 'Zakres egzaminu.'],
    [65, 'Przebieg egzaminu: pisemny i ustny (OUG – ustny), 75%, wynik, egzamin ponowny po 6 miesiącach.'],
    [66, 'Opłaty: egzaminacyjna i za świadectwo, waloryzacja.'],
    [70, 'Wykaz osób z kwalifikacjami w BIP.']
  ];
  route('prawo', (_, params) => {
    const tab = params.get('t') || 'akty';
    const tabs = [['akty', 'Akty prawne'], ['pgg', 'Kluczowe przepisy Pgg'], ['tab', 'Tabele wymagań'], ['zag', 'Zagadnienia egzaminacyjne'], ['pdf', 'Dokumenty offline']];
    main.innerHTML = `
      <div class="crumbs"><a href="#/">Start</a> / Prawo</div>
      <h1>Prawo</h1>
      <div class="chips" role="tablist">${tabs.map(([k, l]) => `<a class="chip ${tab === k ? 'accent' : ''}" role="tab" aria-selected="${tab === k}" href="#/prawo?t=${k}">${l}</a>`).join('')}</div>
      <div id="lv"></div>
      ${footer()}`;
    const lv = $('#lv');
    if (tab === 'akty') {
      const filters = [['', 'Wszystkie'], ['all', 'Podstawowe'], ['podziemne', 'Podziemne'], ['odkrywkowe', 'Odkrywkowe'], ['otworowe', 'Otworowe'], ['mierniczy', 'Mierniczy'], ['geolog', 'Geolog górniczy'], ['geologia', 'Geologia'], ['ratownictwo', 'Ratownictwo'], ['bhp', 'BHP']];
      let f = params.get('f') || ''; let s = '';
      lv.innerHTML = `
        <p class="lead">Akty z zestawienia WUG „Wymagana wiedza w zakresie prawa”, zweryfikowane w bazie Sejmu (ELI/ISAP). Linki prowadzą do ISAP, gdzie znajdziesz tekst ogłoszony, teksty jednolite i zmiany.</p>
        <div class="chips">${filters.map(([k, l]) => `<button type="button" class="chip" data-f="${k}" aria-pressed="${f === k}">${l}</button>`).join('')}</div>
        <input type="search" id="actQ" placeholder="Filtruj akty…" style="width:100%;max-width:420px;padding:8px 12px;border-radius:10px;border:1px solid var(--line);background:var(--surface);color:var(--ink);font:inherit;margin-bottom:12px">
        <div id="actList" class="qlist"></div>
        <h2>Akty proceduralne</h2>
        <ul>${PROC_ACTS.map((a) => `<li>${ext(a.url, a.title)} <span class="muted">(${esc(a.addr)})</span></li>`).join('')}</ul>`;
      const draw = () => {
        const list = ACTS.filter((a) => (!f || a.tags.includes(f) || (f !== 'all' && a.tags.includes('all'))) && (!s || norm(a.title).includes(norm(s))));
        $('#actList').innerHTML = list.map((a) => `
          <div class="card" style="padding:14px 16px">
            <div>${a.url ? ext(a.url, a.title) : esc(a.title)}</div>
            <div class="chips" style="margin:8px 0 0">
              ${a.addr ? `<span class="chip">${esc(a.addr)}</span>` : '<span class="chip">adres nie zweryfikowany</span>'}
              ${a.tjAddr ? `<a class="chip info" href="${a.tjUrl}" target="_blank" rel="noopener">tekst jednolity: ${esc(a.tjAddr)}</a>` : ''}
              ${/uchylon/.test(a.status || '') ? '<span class="chip warn">uznany za uchylony</span>' : a.status === 'obowiązujący' || /jednolity/.test(a.status || '') ? '<span class="chip ok">obowiązujący</span>' : ''}
            </div>
            ${a.note ? `<p class="muted" style="margin:8px 0 0">${esc(a.note)}</p>` : ''}
          </div>`).join('') || '<p class="muted">Brak wyników.</p>';
      };
      $$('[data-f]', lv).forEach((b) => b.addEventListener('click', () => { f = b.dataset.f; $$('[data-f]', lv).forEach((x) => x.setAttribute('aria-pressed', x === b)); draw(); }));
      $('#actQ').addEventListener('input', (e) => { s = e.target.value; draw(); });
      draw();
    }
    if (tab === 'pgg') {
      lv.innerHTML = `
        <p class="lead">Dział IV Prawa geologicznego i górniczego – „Kwalifikacje, rzeczoznawcy i odpowiedzialność zawodowa” (tekst jednolity Dz.U. 2026 poz. 69). Kliknij artykuł, aby otworzyć go w PDF.</p>
        <div class="qlist">${ART_SUMMARY.map(([n, t]) => `<a class="card qitem" href="${pdfPage('pgg', META.pggPage[n])}" target="_blank" rel="noopener"><div><strong>Art. ${n}</strong><div class="muted">${esc(t)}</div></div><span class="arrow">↗</span></a>`).join('')}</div>
        <p style="margin-top:12px">${ext(LINKS.isapPgg, 'Pgg w ISAP')} · ${ext(META.docs.pgg, 'Pełny tekst jednolity (PDF, offline)')}</p>`;
    }
    if (tab === 'tab') {
      const parts = { A: 'Część A – podziemne, magazynowanie/składowanie metodą podziemną, art. 2 ust. 1', B: 'Część B – odkrywkowe', C: 'Część C – otworowe, składowanie CO₂, roboty geologiczne', D: 'Część D – magazynowanie substancji i składowanie odpadów (budowlana, ochrona środowiska)', Z: 'Załączniki 2–7' };
      lv.innerHTML = `
        <p class="lead">Rozporządzenie Ministra Przemysłu z 25 czerwca 2024 r. w sprawie kwalifikacji w zakresie górnictwa i ratownictwa górniczego (Dz.U. 2024 poz. 992). Każda tabela określa: tytuł zawodowy, zakres studiów / podyplomowych / egzaminów uzupełniających lub kwalifikacje technika, czas i rodzaj praktyki.</p>
        ${Object.entries(parts).map(([k, l]) => `<h2>${esc(l)}</h2><div class="table-wrap"><table class="stack"><thead><tr><th>Tabela</th><th>Zakres</th><th>Praktyka</th><th>Str.</th></tr></thead><tbody>
          ${TABLES.filter((t) => t.id[0] === k).map((t) => `<tr><td data-l="Tabela"><strong>${t.id}</strong></td><td data-l="Zakres">${esc(t.t)}</td><td data-l="Praktyka">${t.r ? (t.r[0] === t.r[1] ? fmtMonths(t.r[0]) : fmtMonths(t.r[0]) + ' – ' + fmtMonths(t.r[1])) : '—'}</td><td data-l="Strona"><a href="${pdfPage('rozp992', t.p)}" target="_blank" rel="noopener">${t.p} ↗</a></td></tr>`).join('')}
        </tbody></table></div>`).join('')}
        <p class="muted" style="margin-top:10px">Zakres „Praktyka” to najkrótszy i najdłuższy okres występujący w tabeli – zależy od wykształcenia. Minima programowe (ECTS) i ramowe programy kursów: ${ext(LINKS.wugMinima, 'WUG – minima modułów kształcenia')}.</p>`;
    }
    if (tab === 'zag') {
      lv.innerHTML = `
        <p class="lead">Wybrane zagadnienia prawne, których znajomości WUG wymaga od kandydatów na kierowników ruchu i kierownictwo ratownictwa (egzamin przed Prezesem WUG). Przydatne także na egzaminach przed OUG.</p>
        <div class="grid cols-2">
          <div class="card"><h3>Z ustawy Pgg</h3><ul>${TOPICS.ustawa.map((t) => `<li>${esc(t)}</li>`).join('')}</ul></div>
          <div class="card"><h3>Ratownictwo (art. 54 pkt 2)</h3><ul>${TOPICS.ratownictwo.map((t) => `<li>${esc(t)}</li>`).join('')}</ul></div>
        </div>
        <div class="card" style="margin-top:14px"><h3>Z rozporządzeń wykonawczych</h3><ul class="cols">${TOPICS.rozporzadzenia.map((t) => `<li>${esc(t)}</li>`).join('')}</ul></div>
        <p style="margin-top:10px">${ext(LINKS.wugWiedza, 'Źródło: WUG – Wymagana wiedza w zakresie prawa')}</p>`;
    }
    if (tab === 'pdf') {
      const docs = [['rozp992', 'Rozporządzenie MP z 25.06.2024 r. – kwalifikacje w zakresie górnictwa i ratownictwa (Dz.U. 2024 poz. 992)', '5,1 MB'], ['pgg', 'Prawo geologiczne i górnicze – tekst jednolity (Dz.U. 2026 poz. 69)', 'PDF'], ['geol', 'Rozporządzenie MKiŚ z 11.02.2026 r. – kwalifikacje w zakresie geologii (Dz.U. 2026 poz. 249)', 'PDF'], ['pytGeolog', 'Pytania egzaminacyjne – geolog górniczy (WUG, 15.04.2026)', '0,7 MB'], ['pytMierniczy', 'Pytania egzaminacyjne – mierniczy górniczy (WUG, 15.04.2026)', '0,7 MB'], ['oug', 'Rozporządzenie MAP z 1.03.2022 r. – nazwy, siedziby i właściwość OUG (Dz.U. 2022 poz. 525)', 'PDF']];
      lv.innerHTML = `<p class="lead">Dokumenty zapisane w aplikacji – działają bez internetu po pierwszym otwarciu.</p>
        <div class="qlist">${docs.map(([k, t, s]) => `<a class="card qitem" href="${META.docs[k]}" target="_blank" rel="noopener"><div><strong>${esc(t)}</strong><div class="meta" style="margin-top:6px"><span class="chip">${s}</span></div></div><span class="arrow">↗</span></a>`).join('')}</div>`;
    }
  });

  // ═══════════════ PYTANIA ═══════════════
  const SECTION_LINK = {
    'Ustawa – Prawo geologiczne i górnicze': META.docs.pgg,
    'Rozp. w sprawie dokumentacji mierniczo-geologicznej (2015)': 'https://isap.sejm.gov.pl/isap.nsf/DocDetails.xsp?id=WDU20150001941',
    'Rozp. w sprawie zagrożeń naturalnych (2013)': 'https://isap.sejm.gov.pl/isap.nsf/DocDetails.xsp?id=WDU20130000230',
    'Rozp. – ruch podziemnych zakładów górniczych (2016)': 'https://isap.sejm.gov.pl/isap.nsf/DocDetails.xsp?id=WDU20170001118',
    'Rozp. – ruch odkrywkowego zakładu górniczego (2013)': 'https://isap.sejm.gov.pl/isap.nsf/DocDetails.xsp?id=WDU20130001008',
    'Rozp. – ruch zakładów otworowych (2014)': 'https://isap.sejm.gov.pl/isap.nsf/DocDetails.xsp?id=WDU20140000812',
    'Rozp. w sprawie operatu ewidencyjnego (2011)': 'https://isap.sejm.gov.pl/isap.nsf/DocDetails.xsp?id=WDU20112621568'
  };
  route('pytania', (_, params) => {
    const bank = params.get('b') || store.get('qbank', 'geolog');
    store.set('qbank', bank);
    const all = (QUESTIONS[bank] || []).map((q) => ({ ...q, key: `${bank}|${q.s}|${q.n}` }));
    const sections = [...new Set(all.map((q) => q.s))];
    const st = store.get('qs', {});
    const cfg = store.get('qcfg', { sec: '', filt: 'all', shuffle: false });
    const counts = { k: 0, r: 0 };
    all.forEach((q) => { const v = st[q.key]; if (v && v.s) counts[v.s]++; });
    main.innerHTML = `
      <div class="crumbs"><a href="#/">Start</a> / Pytania</div>
      <h1>Pytania egzaminacyjne WUG</h1>
      <p class="lead">Oficjalne zestawy pytań WUG (stan na 15.04.2026). <strong>WUG publikuje wyłącznie treść pytań – bez odpowiedzi.</strong> Ucz się z przepisem obok: zapisz własną odpowiedź z podstawą prawną i oceniaj, czy już umiesz.</p>
      <div class="chips">
        <a class="chip ${bank === 'geolog' ? 'accent' : ''}" href="#/pytania?b=geolog">Geolog górniczy (${QUESTIONS.geolog.length})</a>
        <a class="chip ${bank === 'mierniczy' ? 'accent' : ''}" href="#/pytania?b=mierniczy">Mierniczy górniczy (${QUESTIONS.mierniczy.length})</a>
      </div>
      <div class="stats" style="margin-bottom:14px">
        <div class="stat"><b>${all.length}</b><span>pytań w zestawie</span></div>
        <div class="stat"><b id="stK" style="color:var(--ok)">${counts.k}</b><span>umiem</span></div>
        <div class="stat"><b id="stR" style="color:var(--warn)">${counts.r}</b><span>do powtórki</span></div>
        <div class="stat"><b id="stN">${all.length - counts.k - counts.r}</b><span>nieocenione</span></div>
      </div>
      <div class="card" style="margin-bottom:14px;display:flex;gap:10px;flex-wrap:wrap;align-items:center">
        <label>Akt: <select id="qSec"><option value="">Wszystkie (${all.length})</option>${sections.map((s) => `<option value="${esc(s)}" ${cfg.sec === s ? 'selected' : ''}>${esc(s)} (${all.filter((q) => q.s === s).length})</option>`).join('')}</select></label>
        <label>Pokaż: <select id="qFilt">
          <option value="all" ${cfg.filt === 'all' ? 'selected' : ''}>wszystkie</option>
          <option value="new" ${cfg.filt === 'new' ? 'selected' : ''}>nieocenione</option>
          <option value="r" ${cfg.filt === 'r' ? 'selected' : ''}>do powtórki</option>
          <option value="k" ${cfg.filt === 'k' ? 'selected' : ''}>umiem</option>
          <option value="note" ${cfg.filt === 'note' ? 'selected' : ''}>z notatką</option>
        </select></label>
        <label class="check"><input type="checkbox" id="qShuf" ${cfg.shuffle ? 'checked' : ''}> losowa kolejność</label>
        <span style="flex:1"></span>
        <button class="btn small" id="simBtn" type="button">Symulacja: 20 losowych pytań</button>
        ${bank === 'geolog' ? `<a class="btn small" href="${META.docs.pytGeolog}" target="_blank" rel="noopener">PDF WUG</a>` : `<a class="btn small" href="${META.docs.pytMierniczy}" target="_blank" rel="noopener">PDF WUG</a>`}
      </div>
      <div id="fcWrap"></div>
      <div class="note"><p>Uwaga WUG: kandydaci na geologa / mierniczego w zakładach innych niż podziemne oraz w zakładach robót geologicznych pomijają zagadnienia dotyczące podziemnych zakładów górniczych. Egzamin pisemny u Prezesa WUG to test 20 pytań jednokrotnego wyboru; próg 75% (15 pytań).</p></div>
      ${footer()}`;

    let list = [];
    let idx = 0;
    let sim = null;
    const build = () => {
      list = all.filter((q) => (!cfg.sec || q.s === cfg.sec)).filter((q) => {
        const v = st[q.key] || {};
        if (cfg.filt === 'new') return !v.s; if (cfg.filt === 'r') return v.s === 'r'; if (cfg.filt === 'k') return v.s === 'k'; if (cfg.filt === 'note') return !!v.note; return true;
      });
      if (cfg.shuffle) list = shuffle(list.slice());
      idx = Math.min(store.get('qidx.' + bank + '.' + cfg.sec + '.' + cfg.filt, 0), Math.max(0, list.length - 1));
      if (cfg.shuffle) idx = 0;
    };
    const shuffle = (a) => { for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [a[i], a[j]] = [a[j], a[i]]; } return a; };
    const persist = () => {
      store.set('qs', st);
      const c = { k: 0, r: 0 }; all.forEach((q) => { const v = st[q.key]; if (v && v.s) c[v.s]++; });
      $('#stK').textContent = c.k; $('#stR').textContent = c.r; $('#stN').textContent = all.length - c.k - c.r;
    };
    const drawCard = () => {
      const wrap = $('#fcWrap');
      const L = sim ? sim.list : list;
      const i = sim ? sim.i : idx;
      if (!L.length) { wrap.innerHTML = '<div class="card"><p>Brak pytań dla wybranych filtrów.</p></div>'; return; }
      if (sim && sim.i >= L.length) {
        const ok = sim.res.filter(Boolean).length; const pct = Math.round(ok / L.length * 100);
        wrap.innerHTML = `<div class="card"><h2 style="margin-top:0">Wynik symulacji: ${ok}/${L.length} (${pct}%)</h2>
          <div class="note ${pct >= 75 ? 'ok' : 'warn'}"><p>${pct >= 75 ? 'Powyżej progu 75% – w prawdziwym egzaminie przeszedłbyś do części ustnej.' : 'Poniżej progu 75%. Pytania oznaczone „nie wiem” trafiły do powtórki.'}</p></div>
          <p class="muted">Ocena własna – WUG nie publikuje odpowiedzi.</p>
          <div class="btns"><button class="btn primary" id="simAgain" type="button">Nowa symulacja</button><button class="btn" id="simEnd" type="button">Wróć do fiszek</button></div></div>`;
        $('#simAgain').addEventListener('click', startSim); $('#simEnd').addEventListener('click', () => { sim = null; drawCard(); });
        return;
      }
      const q = L[i]; const v = st[q.key] || {};
      wrap.innerHTML = `
        <div class="card fc">
          <div class="fc-top">
            <span class="chip">${esc(q.s)} · pyt. ${q.n}</span>
            <span class="muted">${sim ? 'Symulacja ' : ''}${i + 1} / ${L.length}</span>
          </div>
          ${sim ? `<div class="progress"><i style="width:${Math.round(i / L.length * 100)}%"></i></div>` : ''}
          <div class="q">${esc(q.q)}</div>
          <label class="muted" for="note">Twoja odpowiedź / notatka (z podstawą prawną)</label>
          <textarea id="note" placeholder="np. art. … ust. … Pgg – treść odpowiedzi">${esc(v.note || '')}</textarea>
          <div class="btns">
            <a class="btn small" href="${esc(SECTION_LINK[q.s] || '#')}" target="_blank" rel="noopener">Otwórz akt ↗</a>
            ${v.s ? `<span class="chip ${v.s === 'k' ? 'ok' : 'warn'}">${v.s === 'k' ? 'umiem' : 'do powtórki'}</span>` : ''}
          </div>
          <div class="fc-nav">
            ${sim ? '<span></span>' : '<button class="btn" id="prev" type="button">← Poprzednie</button>'}
            <div class="btns">
              <button class="btn warn" id="rep" type="button">${sim ? 'Nie wiem' : 'Do powtórki'}</button>
              <button class="btn ok" id="know" type="button">${sim ? 'Wiem' : 'Umiem'}</button>
            </div>
            ${sim ? '<button class="btn" id="simStop" type="button">Przerwij</button>' : '<button class="btn" id="next" type="button">Następne →</button>'}
          </div>
        </div>`;
      $('#note').addEventListener('input', (e) => { const cur = st[q.key] || {}; cur.note = e.target.value; st[q.key] = cur; persist(); });
      const mark = (s) => { const cur = st[q.key] || {}; cur.s = s; st[q.key] = cur; persist(); if (sim) { sim.res[sim.i] = s === 'k'; sim.i++; } else { idx = Math.min(idx + 1, list.length - 1); saveIdx(); } drawCard(); };
      $('#know').addEventListener('click', () => mark('k'));
      $('#rep').addEventListener('click', () => mark('r'));
      if (!sim) {
        $('#prev').addEventListener('click', () => { idx = Math.max(0, idx - 1); saveIdx(); drawCard(); });
        $('#next').addEventListener('click', () => { idx = Math.min(list.length - 1, idx + 1); saveIdx(); drawCard(); });
      } else $('#simStop').addEventListener('click', () => { sim = null; drawCard(); });
    };
    const saveIdx = () => { if (!cfg.shuffle) store.set('qidx.' + bank + '.' + cfg.sec + '.' + cfg.filt, idx); };
    const startSim = () => { const pool = all.filter((q) => !cfg.sec || q.s === cfg.sec); sim = { list: shuffle(pool.slice()).slice(0, 20), i: 0, res: [] }; drawCard(); $('#fcWrap').scrollIntoView({ behavior: 'smooth', block: 'start' }); };
    $('#qSec').addEventListener('change', (e) => { cfg.sec = e.target.value; store.set('qcfg', cfg); sim = null; build(); drawCard(); });
    $('#qFilt').addEventListener('change', (e) => { cfg.filt = e.target.value; store.set('qcfg', cfg); sim = null; build(); drawCard(); });
    $('#qShuf').addEventListener('change', (e) => { cfg.shuffle = e.target.checked; store.set('qcfg', cfg); sim = null; build(); drawCard(); });
    $('#simBtn').addEventListener('click', startSim);
    document.onkeydown = (e) => {
      if (parseHash().parts[0] !== 'pytania' || e.target.tagName === 'TEXTAREA' || e.target.tagName === 'INPUT' || e.target.tagName === 'SELECT') return;
      if (e.key === 'ArrowRight') { const b = $('#next'); b && b.click(); }
      if (e.key === 'ArrowLeft') { const b = $('#prev'); b && b.click(); }
    };
    build(); drawCard();
  });

  // ═══════════════ SŁOWNIK ═══════════════
  route('slownik', () => {
    main.innerHTML = `
      <div class="crumbs"><a href="#/">Start</a> / Słownik</div>
      <h1>Słownik pojęć</h1>
      <div class="qlist">${GLOSSARY.map(([t, d]) => `<div class="card"><strong>${esc(t)}</strong><p style="margin:6px 0 0;color:var(--ink-2)">${esc(d)}</p></div>`).join('')}</div>
      <h2>Przygotowanie zawodowe – co sprawdza egzamin (art. 54 pkt 1 Pgg)</h2>
      <div class="card">
        <ul>
          <li><strong>Kierownictwo i dozór ruchu</strong> – przepisy Pgg i inne stosowane w ruchu zakładu + zagadnienia prowadzenia ruchu określonego rodzaju zakładów i występujących w nich zagrożeń.</li>
          <li><strong>Mierniczy górniczy</strong> – jw. + czynności mierniczego, kierownika ruchu w odkrywkach bez środków strzałowych, kierownika działu mierniczego, wyższego dozoru w specjalności mierniczej.</li>
          <li><strong>Geolog górniczy</strong> – jw. + czynności geologa, kierownika ruchu w odkrywkach bez środków strzałowych i w zakładach wód leczniczych, termalnych i solanek, kierownika działu geologicznego, wyższego dozoru w specjalności geologicznej.</li>
          <li><strong>Geofizyk górniczy</strong> – jw. + czynności geofizyka, kierownika działu tąpań, kierownika działu geofizyka i technika strzałowa, wyższego dozoru w specjalności geofizycznej i geofizyka i technika strzałowa.</li>
          <li><strong>Ratownictwo</strong> – ${esc(TOPICS.ratownictwo.join('; '))}.</li>
        </ul>
      </div>
      ${footer()}`;
  });

  // ═══════════════ WYSZUKIWANIE ═══════════════
  function buildIndex() {
    const idx = [];
    QUALS.forEach((q) => idx.push({ type: 'Kwalifikacja', title: q.title, text: [q.intro, q.level, (q.specs || []).join(' '), (q.paths || []).map((p) => p.who + ' ' + p.edu + ' ' + p.time).join(' '), q.patternNote, (q.equivalents || []).join(' '), q.basis].join(' '), href: '#/k/' + q.id }));
    PROCEDURE.forEach((s) => idx.push({ type: 'Procedura', title: s.title, text: s.body + ' ' + s.law, href: '#/procedura' }));
    PROCEDURE_GEO.forEach((s) => idx.push({ type: 'Procedura – geologia', title: s.title, text: s.body, href: '#/procedura?t=geo' }));
    GLOSSARY.forEach(([t, d]) => idx.push({ type: 'Słownik', title: t, text: d, href: '#/slownik' }));
    ACTS.forEach((a) => idx.push({ type: 'Akt prawny', title: a.title, text: (a.addr || '') + ' ' + (a.note || ''), href: a.url || '#/prawo', ext: !!a.url }));
    ART_SUMMARY.forEach(([n, t]) => idx.push({ type: 'Pgg', title: 'Art. ' + n + ' Pgg', text: t + ' art ' + n, href: pdfPage('pgg', META.pggPage[n]), ext: true }));
    TABLES.forEach((t) => idx.push({ type: 'Tabela rozporządzenia', title: 'Tabela ' + t.id + ' – ' + t.t, text: t.t, href: pdfPage('rozp992', t.p), ext: true }));
    CHECKLIST.forEach((c) => idx.push({ type: 'Dokumenty', title: c.t, text: c.t, href: '#/procedura?t=dok' }));
    OUG.forEach((o) => idx.push({ type: 'OUG', title: o.n, text: o.s + ' ' + o.w, href: '#/procedura?t=oug' }));
    idx.push({ type: 'Opłaty', title: 'Opłata egzaminacyjna i za świadectwo ' + FEES.rok, text: `opłata egzamin ${FEES.egzamin} świadectwo ${FEES.swiadectwo} rachunek konto przelew uznanie ${FEES.uznanie}`, href: '#/procedura?t=oplaty' });
    ['geolog', 'mierniczy'].forEach((b) => QUESTIONS[b].forEach((q) => idx.push({ type: 'Pytanie – ' + (b === 'geolog' ? 'geolog' : 'mierniczy'), title: q.q, text: q.s, href: '#/pytania?b=' + b, q: true })));
    idx.forEach((e) => { e.n = norm(e.title + ' ' + e.text); });
    return idx;
  }
  let INDEX = null;
  route('szukaj', (_, params) => {
    INDEX = INDEX || buildIndex();
    const q = params.get('q') || '';
    $('#q').value = q;
    // prosty „stemming” dla odmiany polskiej: odcinamy końcówkę dłuższych słów
    const terms = norm(q).split(/\s+/).filter((t) => t.length > 1).map((t) => (t.length > 6 ? t.slice(0, -2) : t));
    const hits = terms.length ? INDEX.filter((e) => terms.every((t) => e.n.includes(t))) : [];
    hits.sort((a, b) => (a.q ? 1 : 0) - (b.q ? 1 : 0) || (terms.every((t) => norm(b.title).includes(t)) ? 1 : 0) - (terms.every((t) => norm(a.title).includes(t)) ? 1 : 0));
    const qHits = hits.filter((h) => h.q); const other = hits.filter((h) => !h.q);
    const hl = (s) => { let out = esc(s); terms.forEach((t) => { const re = new RegExp('(' + t.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + ')', 'gi'); out = out.replace(re, '<mark>$1</mark>'); }); return out; };
    const item = (h) => `<a class="card qitem hit" href="${h.href}" ${h.ext ? 'target="_blank" rel="noopener"' : ''}><div><span class="chip">${esc(h.type)}</span><div style="margin-top:6px"><strong>${hl(h.title)}</strong></div></div><span class="arrow">${h.ext ? '↗' : '›'}</span></a>`;
    main.innerHTML = `
      <h1>Wyniki: „${esc(q)}”</h1>
      ${!terms.length ? '<p>Wpisz co najmniej 2 znaki.</p>' : !hits.length ? '<p>Brak wyników. Spróbuj innego słowa (wyszukiwarka ignoruje polskie znaki).</p>' : ''}
      ${other.length ? `<div class="qlist">${other.slice(0, 40).map(item).join('')}</div>` : ''}
      ${qHits.length ? `<h2>Pytania egzaminacyjne (${qHits.length})</h2><div class="qlist">${qHits.slice(0, 30).map(item).join('')}</div>${qHits.length > 30 ? '<p class="muted">Pokazano 30 pierwszych.</p>' : ''}` : ''}`;
  });
  let st;
  $('#q').addEventListener('input', (e) => { clearTimeout(st); const v = e.target.value; st = setTimeout(() => { if (v.trim().length > 1) location.hash = '#/szukaj?q=' + encodeURIComponent(v.trim()); }, 300); });
  $('#searchForm').addEventListener('submit', (e) => { e.preventDefault(); const v = $('#q').value.trim(); if (v) location.hash = '#/szukaj?q=' + encodeURIComponent(v); });

  render();

  // ── Instalacja PWA ──
  let deferred = null;
  window.addEventListener('beforeinstallprompt', (e) => { e.preventDefault(); deferred = e; $('#installBtn').hidden = false; });
  $('#installBtn').addEventListener('click', async () => { if (!deferred) return; deferred.prompt(); await deferred.userChoice; deferred = null; $('#installBtn').hidden = true; });
  window.addEventListener('appinstalled', () => { $('#installBtn').hidden = true; toast('Aplikacja zainstalowana'); });

  // ── Service worker (offline) ──
  if ('serviceWorker' in navigator && (location.protocol === 'https:' || location.hostname === 'localhost' || location.hostname === '127.0.0.1')) {
    navigator.serviceWorker.register('sw.js').catch(() => {});
  }
})();
