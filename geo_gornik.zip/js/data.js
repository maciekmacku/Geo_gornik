// Kompendium kwalifikacji górniczych, wiertniczych i geologicznych – dane merytoryczne.
// Źródła: Pgg (Dz.U. 2026 poz. 69), rozp. MP z 25.06.2024 (Dz.U. 2024 poz. 992),
// rozp. MKiŚ z 11.02.2026 (Dz.U. 2026 poz. 249), strony WUG (wug.gov.pl, gov.pl/web/wug).
// Stan prawny i opłaty: 2 października 2026 r.

window.META = {
  stan: '2 października 2026 r.',
  docs: {
    rozp992: 'docs/rozp-kwalifikacje-gornicze-2024-992.pdf',
    pgg: 'docs/pgg-tekst-jednolity-2026-69.pdf',
    geol: 'docs/rozp-kwalifikacje-geologia-2026-249.pdf',
    pytGeolog: 'docs/pytania-geolog-gorniczy-2026.pdf',
    pytMierniczy: 'docs/pytania-mierniczy-gorniczy-2026.pdf',
    oug: 'docs/rozp-oug-2022-525.pdf'
  },
  // W tekście jednolitym Pgg (Dz.U. 2026 poz. 69) numer strony PDF = numer strony Dziennika Ustaw
  pggPage: { 2: 3, 86: 72, '69a': 63, 71: 63, 50: 49, 51: 50, 52: 50, 53: 51, 54: 52, 55: 53, 56: 54, 57: 55, 58: 55, 59: 58, 60: 59, 61: 60, 62: 61, 63: 61, 64: 61, 65: 61, 66: 62, 70: 63 }
};

window.LINKS = {
  wugKwalifikacje: 'https://www.gov.pl/web/wug/kwalifikacje-gornicze',
  wugGornictwo: 'https://www.gov.pl/web/wug/stwierdzanie-kwalifikacji-w-zakresie-gornictwa-i-ratownictwa-gorniczego',
  wugMierniczyGeolog: 'https://www.gov.pl/web/wug/stwierdzanie-kwalifikacji-mierniczego-gorniczego-i-geologa-gorniczego',
  wugUznawanie: 'https://www.gov.pl/web/wug/uznawanie-nabytych-w-panstwach-czlonkowskich-unii-europejskiej-konfederacji-szwajcarskiej-lub-panstwach-czlonkowskich-europejskiego-porozumienia-o-wolnym-handlu-efta--stronach-umowy-o-europejskim-obszarze-gospodarczym-kwalifikacji-do-wykonywania-gorniczych-zawodow-regulowanych',
  wugWiedza: 'https://www.gov.pl/web/wug/wymagana-wiedza-w-zakresie-prawa',
  wugMinima: 'https://www.gov.pl/web/wug/minima-modulow-ksztalcenia-i-planow-studiow',
  wugOug: 'https://www.gov.pl/web/wug/okregowe-urzedy-gornicze',
  wugArchProcedury: 'https://www.wug.gov.pl/prawo/procedury',
  wugArchFormularze: 'https://www.wug.gov.pl/prawo/wnioski_formularze',
  wugArchOplaty: 'https://www.wug.gov.pl/prawo/oplata',
  wugArchPytania: 'https://www.wug.gov.pl/prawo/przykladowe-pytania-egzaminacyjne',
  wugArchMinima: 'https://www.wug.gov.pl/prawo/minima',
  isapPgg: 'https://isap.sejm.gov.pl/isap.nsf/DocDetails.xsp?id=WDU20260000069',
  isapRozp992: 'https://isap.sejm.gov.pl/isap.nsf/DocDetails.xsp?id=WDU20240000992',
  isapGeol: 'https://isap.sejm.gov.pl/isap.nsf/DocDetails.xsp?id=WDU20260000249',
  mkisGeolog: 'https://www.gov.pl/web/klimat/kwalifikacje-geologiczne'
};

window.FORMS = {
  f1: { nr: 1, title: 'Wniosek do dyrektora OUG – art. 58 ust. 1 pkt 1 Pgg (podziemne zakłady górnicze)', url: 'https://www.wug.gov.pl/download/1-Formularz-wniosku-do-Dyrektora-OUG-o-stwierdzenie-kwalifikacji-art.-58_ust_1_pkt-1_Pgg-podziemne-zaklady-gornicze,8440.rtf', fmt: 'RTF' },
  f2: { nr: 2, title: 'Wniosek do dyrektora OUG – art. 58 ust. 1 pkt 3 i 3a Pgg (odkrywkowe zakłady górnicze)', url: 'https://www.wug.gov.pl/download/2-Formularz-wniosku-do-Dyrektora-OUG-o-stwierdzenie-kwalifikacji-art_58_ust_1_pkt_3_i_3a_Pgg-odkrywkowe-zaklady-gornicze,8441.rtf', fmt: 'RTF' },
  f3: { nr: 3, title: 'Wniosek do dyrektora OUG – art. 58 ust. 1 pkt 4 i 4a Pgg (otworowe zakłady górnicze i roboty geologiczne)', url: 'https://www.wug.gov.pl/download/3-Formularz-wniosku-do-Dyrektora-OUG-o-stwierdzenie-kwalifikacji-art_58_ust_1_pkt_4_i_4a_Pgg-otworowe-zaklady-gornicze,8442.rtf', fmt: 'RTF' },
  f4: { nr: 4, title: 'Wniosek do dyrektora OUG – art. 58 ust. 1 pkt 10 Pgg (specjalności budowlana i ochrona środowiska)', url: 'https://www.wug.gov.pl/download/4-Formularz-wniosku-do-Dyrektora-OUG-o-stwierdzenie-kwalifikacji-art_58_ust_1_pkt_10-budowlana-i-ochrona-srodowiska,8443.rtf', fmt: 'RTF' },
  f5: { nr: 5, title: 'Wniosek do Prezesa WUG – art. 58 ust. 2 Pgg', url: 'https://www.wug.gov.pl/download/5-Formularz-wniosku-do-Prezesa-WUG-o-stwierdzenie-kwalifikacji-art_58_ust_2_Pgg,8444.rtf', fmt: 'RTF' },
  f6: { nr: 6, title: 'Wniosek o uznanie kwalifikacji zawodowych (zagranicznych)', url: 'https://www.wug.gov.pl/download/wniosek-o-uznanie-kawalifikacji_pdf,6431.pdf', fmt: 'PDF' }
};

window.FEES = {
  rok: 2026,
  egzamin: '411,54 zł',
  egzaminPonowny: '411,54 zł',
  swiadectwo: '49,45 zł',
  uznanie: '1682,10 zł',
  uznanieOpis: '35% minimalnego wynagrodzenia (4806 zł w 2026 r.)',
  konto: '46 1010 1212 0010 5222 3100 0000',
  bank: 'NBP O/O Katowice',
  odbiorca: 'Prezes Wyższego Urzędu Górniczego, ul. Poniatowskiego 31, 40-055 Katowice',
  podstawa: 'art. 66 Pgg; stawki na 2026 r. – obwieszczenie (M.P. z 2025 r. poz. 1027)',
  tytulPrzyklady: [
    'Jan Kowalski (WUG) Opłata egzaminacyjna – stwierdzenie kwalifikacji do wykonywania czynności kierownika ruchu podziemnego zakładu górniczego wydobywającego (…)',
    'Tomasz Nowak (OUG …) Opłata egzaminacyjna – stwierdzenie kwalifikacji do wykonywania czynności w wyższym dozorze ruchu w specjalności górniczej w podziemnych zakładach górniczych wydobywających (…)',
    'Opłata egzaminacyjna – mierniczy/geolog górniczy'
  ]
};

window.OUG = [
  { n: 'OUG w Gdańsku', s: 'Gdańsk', w: 'województwa kujawsko-pomorskie i pomorskie oraz obszary morskie RP' },
  { n: 'OUG w Katowicach', s: 'Katowice', w: 'woj. opolskie; część śląskiego (m.in. Bytom, Chorzów, Częstochowa, Dąbrowa Górnicza, Jaworzno, Katowice, Mysłowice, Piekary Śl., Ruda Śl., Siemianowice Śl., Sosnowiec, Świętochłowice, Tychy, Zabrze; powiaty: będziński, bieruńsko-lędziński, częstochowski, kłobucki, lubliniecki, myszkowski, pszczyński bez gm. Pawłowice, tarnogórski; gminy Bestwina i Czechowice-Dziedzice); część małopolskiego (Libiąż, Brzeszcze, Chełmek, gm. i m. Oświęcim)' },
  { n: 'OUG w Kielcach', s: 'Kielce', w: 'województwa łódzkie i świętokrzyskie; powiat tarnobrzeski i Tarnobrzeg' },
  { n: 'OUG w Krakowie', s: 'Kraków', w: 'woj. małopolskie (bez Libiąża, Brzeszcz, Chełmka, Oświęcimia) oraz powiat zawierciański' },
  { n: 'OUG w Krośnie', s: 'Krosno', w: 'woj. podkarpackie (bez powiatu tarnobrzeskiego i Tarnobrzega)' },
  { n: 'OUG w Lublinie', s: 'Lublin', w: 'województwa lubelskie i podlaskie' },
  { n: 'OUG w Poznaniu', s: 'Poznań', w: 'województwa lubuskie, wielkopolskie i zachodniopomorskie' },
  { n: 'OUG w Rybniku', s: 'Jankowice', w: 'część woj. śląskiego: powiaty bielski (bez Bestwiny i Czechowic-Dziedzic), cieszyński, gliwicki, mikołowski, raciborski, rybnicki, wodzisławski, żywiecki; Bielsko-Biała, Gliwice, Jastrzębie-Zdrój, Rybnik, Żory; gmina Pawłowice' },
  { n: 'OUG w Warszawie', s: 'Warszawa', w: 'województwa mazowieckie i warmińsko-mazurskie' },
  { n: 'OUG we Wrocławiu', s: 'Wrocław', w: 'województwo dolnośląskie' }
];

// Organy właściwe
window.ORGANS = {
  OUG: { name: 'Dyrektor okręgowego urzędu górniczego', short: 'Dyrektor OUG', exam: 'Egzamin wyłącznie ustny (art. 65 ust. 4 Pgg).', basis: 'art. 58 ust. 1 Pgg' },
  WUG: { name: 'Prezes Wyższego Urzędu Górniczego', short: 'Prezes WUG', exam: 'Egzamin pisemny (test 20 pytań jednokrotnego wyboru, 4 odpowiedzi) + ustny. Do części ustnej dopuszcza się osoby, które odpowiedziały poprawnie na co najmniej 75% pytań (art. 65 ust. 3 i 5 Pgg).', basis: 'art. 58 ust. 2 Pgg' },
  MKIS: { name: 'Minister właściwy do spraw środowiska (Minister Klimatu i Środowiska)', short: 'Minister KiŚ', exam: 'Egzamin pisemny i ustny; terminy i miejsca ogłaszane w BIP co najmniej 30 dni wcześniej (art. 63 ust. 2, art. 65 Pgg).', basis: 'art. 51 pkt 1 Pgg' },
  MARSZ: { name: 'Marszałek województwa (dolnośląskiego, małopolskiego, mazowieckiego albo pomorskiego)', short: 'Marszałek województwa', exam: 'Egzamin pisemny i ustny; terminy ogłaszane w BIP co najmniej 30 dni wcześniej.', basis: 'art. 51 pkt 2 Pgg' },
  PRAC: { name: 'Pracodawca (bez egzaminu przed organem)', short: 'Pracodawca', exam: 'Brak egzaminu państwowego – pracodawca sprawdza spełnienie wymagań art. 56 Pgg i wystawia zaświadczenie (art. 58 ust. 11 Pgg).', basis: 'art. 56 i art. 58 ust. 11 Pgg' }
};

// Spis tabel załącznika nr 1 do rozp. Dz.U. 2024 poz. 992 (strona = strona PDF / Dziennika Ustaw)
window.TABLES = [
  { id: 'A1', p: 4, t: 'Dozór ruchu – zakład górniczy prowadzący działalność metodą podziemną', r: [3, 18] },
  { id: 'A2', p: 10, t: 'Dozór ruchu – zakład prowadzący działalność określoną w art. 2 ust. 1 Pgg', r: [3, 12] },
  { id: 'A3', p: 14, t: 'Dozór ruchu – podziemne i art. 2 ust. 1 – specjalność budowlana', r: [6, 6] },
  { id: 'A4', p: 15, t: 'Wyższy dozór ruchu – zakład górniczy prowadzący działalność metodą podziemną', r: [12, 60] },
  { id: 'A5', p: 26, t: 'Wyższy dozór ruchu – zakład prowadzący działalność określoną w art. 2 ust. 1 Pgg', r: [12, 60] },
  { id: 'A6', p: 37, t: 'Wyższy dozór ruchu – podziemne i art. 2 ust. 1 – specjalność budowlana', r: [12, 12] },
  { id: 'A7', p: 37, t: 'Kierownik i zastępca kierownika działu ruchu – podziemne zakłady górnicze', r: [12, 60] },
  { id: 'A8', p: 41, t: 'Kierownik działu ruchu – podziemne magazynowanie substancji / składowanie odpadów metodą podziemną', r: [12, 60] },
  { id: 'A9', p: 44, t: 'Kierownik działu ruchu – zakłady z art. 2 ust. 1 Pgg', r: [12, 60] },
  { id: 'A10', p: 49, t: 'Kierownik i zastępca kierownika ruchu – podziemne zakłady górnicze', r: [24, 48] },
  { id: 'A11', p: 50, t: 'Kierownik ruchu – podziemne magazynowanie substancji / składowanie odpadów metodą podziemną', r: [24, 48] },
  { id: 'A12', p: 51, t: 'Kierownik ruchu zakładu – zakłady z art. 2 ust. 1 Pgg', r: [24, 48] },
  { id: 'B1', p: 52, t: 'Dozór ruchu – odkrywki: węgiel brunatny lub z użyciem środków strzałowych', r: [3, 36] },
  { id: 'B2', p: 55, t: 'Dozór ruchu – odkrywki bez użycia środków strzałowych', r: [3, 24] },
  { id: 'B3', p: 58, t: 'Dozór ruchu – odkrywki – specjalność budowlana', r: [12, 12] },
  { id: 'B4', p: 58, t: 'Dozór ruchu – odkrywki – specjalność ochrona środowiska', r: [3, 12] },
  { id: 'B5', p: 59, t: 'Wyższy dozór ruchu – odkrywki: węgiel brunatny lub ze środkami strzałowymi', r: [12, 36] },
  { id: 'B6', p: 62, t: 'Wyższy dozór ruchu – odkrywki bez środków strzałowych', r: [12, 36] },
  { id: 'B7', p: 64, t: 'Wyższy dozór ruchu – odkrywki – specjalność budowlana', r: [12, 12] },
  { id: 'B8', p: 65, t: 'Wyższy dozór ruchu – odkrywki – specjalność ochrona środowiska', r: [18, 36] },
  { id: 'B9', p: 66, t: 'Kierownik działu ruchu – odkrywki: węgiel brunatny lub ze środkami strzałowymi', r: [6, 18] },
  { id: 'B10', p: 68, t: 'Kierownik działu ruchu – odkrywki bez środków strzałowych', r: [6, 18] },
  { id: 'B11', p: 69, t: 'Kierownik działu ruchu ochrona środowiska – odkrywki', r: [18, 18] },
  { id: 'B12', p: 69, t: 'Kierownik ruchu – odkrywki: węgiel brunatny lub ze środkami strzałowymi', r: [18, 36] },
  { id: 'B13', p: 70, t: 'Kierownik ruchu – odkrywki bez środków strzałowych', r: [18, 36] },
  { id: 'C1', p: 71, t: 'Dozór ruchu – otworowe zakłady górnicze', r: [3, 24] },
  { id: 'C2', p: 75, t: 'Dozór ruchu – zakłady wykonujące roboty geologiczne', r: [3, 24] },
  { id: 'C3', p: 79, t: 'Dozór ruchu – otwory, składowanie CO₂, roboty geologiczne – specjalność budowlana', r: [12, 12] },
  { id: 'C4', p: 79, t: 'Wyższy dozór ruchu – otworowe zakłady górnicze', r: [12, 36] },
  { id: 'C5', p: 83, t: 'Wyższy dozór ruchu – zakłady wykonujące roboty geologiczne', r: [12, 36] },
  { id: 'C6', p: 86, t: 'Wyższy dozór ruchu – otwory, CO₂, roboty geologiczne – specjalność budowlana', r: [12, 12] },
  { id: 'C7', p: 87, t: 'Kierownik działu ruchu – otworowe zakłady górnicze', r: [12, 24] },
  { id: 'C8', p: 89, t: 'Kierownik działu ruchu – zakłady wykonujące roboty geologiczne', r: [6, 24] },
  { id: 'C9', p: 91, t: 'Kierownik ruchu – otworowe zakłady górnicze', r: [12, 48] },
  { id: 'C10', p: 92, t: 'Kierownik ruchu – zakłady wykonujące roboty geologiczne', r: [12, 48] },
  { id: 'D1', p: 93, t: 'Dozór ruchu – magazynowanie substancji / składowanie odpadów – budowlana', r: [6, 6] },
  { id: 'D2', p: 93, t: 'Dozór ruchu – magazynowanie substancji / składowanie odpadów – ochrona środowiska', r: [3, 12] },
  { id: 'D3', p: 94, t: 'Wyższy dozór – magazynowanie / składowanie – budowlana', r: [12, 12] },
  { id: 'D4', p: 94, t: 'Wyższy dozór – magazynowanie / składowanie – ochrona środowiska', r: [18, 36] },
  { id: 'D5', p: 95, t: 'Kierownik działu ruchu ochrona środowiska – magazynowanie / składowanie', r: [18, 18] },
  { id: 'Z2', p: 96, t: 'Załącznik nr 2 – mierniczy górniczy', r: [24, 48] },
  { id: 'Z3', p: 97, t: 'Załącznik nr 3 – geolog górniczy', r: [24, 48] },
  { id: 'Z4', p: 99, t: 'Załącznik nr 4 – geofizyk górniczy', r: [24, 48] },
  { id: 'Z5', p: 100, t: 'Załącznik nr 5 – kierownictwo w podmiotach ratownictwa górniczego', r: [36, 84] },
  { id: 'Z6', p: 103, t: 'Załącznik nr 6 – czynności specjalistyczne (kursy, praktyka, wiek)', r: null },
  { id: 'Z7', p: 106, t: 'Załącznik nr 7 – wzór świadectwa', r: null }
];

const TECH = (zakres) => 'technik – kwalifikacje zawodowe w zawodach na poziomie technika dających przygotowanie do pracy ' + zakres;

// Katalog kwalifikacji
window.QUALS = [
  // ───────────────────────── PODZIEMNE ─────────────────────────
  {
    id: 'pz-dozor', group: 'podziemne', level: 'Dozór ruchu',
    title: 'Dozór ruchu – podziemne zakłady górnicze',
    organ: 'OUG', form: 'f1', basis: 'art. 58 ust. 1 pkt 1 Pgg', tables: ['A1', 'A2', 'A3'],
    intro: 'Osoby dozoru ruchu (np. sztygar zmianowy, nadgórnik oddziałowy, mechanik/elektryk oddziałowy) w kopalniach węgla kamiennego, rud miedzi, soli i innych zakładach podziemnych oraz w zakładach z art. 2 ust. 1 Pgg (odwadnianie zlikwidowanych kopalń, kopalnie turystyczne, drążenie tuneli).',
    specs: ['górnicza', 'górnicza – przeróbka mechaniczna węgla', 'wiertnicza', 'geofizyczna', 'górnicze wyciągi szybowe', 'mechaniczna – maszyn i urządzeń dołowych', 'mechaniczna – maszyn i urządzeń na powierzchni', 'elektryczna – maszyn i urządzeń dołowych', 'elektryczna – maszyn i urządzeń na powierzchni', 'elektryczna – teletechniczna i automatyki', 'miernicza', 'geologiczna', 'ochrona środowiska', 'bezpieczeństwa i higieny pracy', 'budowlana (uprawnienia budowlane)'],
    pathsTitle: 'Przykład – specjalność górnicza (tab. A1 lp. 1)',
    paths: [
      { who: 'magister inżynier', edu: 'studia: górnictwo', time: '3 miesiące' },
      { who: 'inżynier', edu: 'studia: górnictwo', time: '6 miesięcy' },
      { who: 'magister inżynier / inżynier', edu: 'studia podyplomowe: górnictwo podziemne', time: '9 miesięcy' },
      { who: 'technik', edu: TECH('w górnictwie podziemnym'), time: '12 miesięcy' }
    ],
    practice: 'praktyka zawodowa pod ziemią w ruchu zakładu górniczego prowadzącego działalność metodą podziemną w danej specjalności',
    patternNote: 'Ten sam schemat (3 / 6 / 9 / 12 miesięcy) obowiązuje w większości specjalności – różnią się wymagane kierunki studiów (np. elektrotechnika, mechanika i budowa maszyn, automatyka i robotyka, miernictwo górnicze/geodezja, geologia, geofizyka). Wyjątki: przeróbka mechaniczna węgla – technik 18 miesięcy; geologiczna – geofizyk 6 miesięcy; specjalność budowlana – uprawnienia budowlane + 6 miesięcy praktyki budowlanej (tab. A3).',
    equivalents: ['Kwalifikacje do dozoru w czynnych zakładach uprawniają też do dozoru w likwidowanych zakładach tego rodzaju (art. 58 ust. 9 Pgg).', 'Kwalifikacje w danej specjalności pozwalają zajmować stanowisko obejmujące więcej niż jeden rodzaj czynności z tej grupy (art. 60 ust. 2 Pgg).'],
    knowledge: ['gornictwo', 'podziemne', 'bhp'],
    questions: null
  },
  {
    id: 'pz-wdozor', group: 'podziemne', level: 'Wyższy dozór ruchu',
    title: 'Wyższy dozór ruchu – podziemne zakłady górnicze',
    organ: 'OUG', form: 'f1', basis: 'art. 58 ust. 1 pkt 1 Pgg', tables: ['A4', 'A5', 'A6'],
    intro: 'Osoby wyższego dozoru ruchu (np. sztygar oddziałowy, kierownik robót górniczych, nadsztygar) w podziemnych zakładach górniczych. Wymagana praktyka w dozorze ruchu w danej specjalności.',
    specs: ['górnicza', 'górnicza – przeróbka mechaniczna węgla', 'wiertnicza', 'geofizyczna', 'górnicze wyciągi szybowe', 'mechaniczna (dołowa / powierzchnia)', 'elektryczna (dołowa / powierzchnia / teletechniczna i automatyki)', 'miernicza', 'geologiczna', 'ochrona środowiska', 'bezpieczeństwa i higieny pracy', 'budowlana (uprawnienia budowlane + 12 mies.)'],
    pathsTitle: 'Przykład – specjalność górnicza (tab. A4 lp. 1)',
    paths: [
      { who: 'magister inżynier / inżynier', edu: 'studia: górnictwo', time: '2 lata w dozorze ruchu pod ziemią albo 3 lata (2 lata w dziale BHP + 1 rok w dozorze)' },
      { who: 'magister inżynier / inżynier', edu: 'studia podyplomowe: górnictwo podziemne', time: '3 lata w dozorze albo 4 lata (3 lata w dziale BHP + 1 rok w dozorze)' },
      { who: 'technik', edu: TECH('w górnictwie podziemnym'), time: '2 lata w dozorze albo 3 lata (2 lata w dziale BHP + 1 rok w dozorze)' }
    ],
    practice: 'praktyka zawodowa pod ziemią w zakresie obejmującym czynności w dozorze ruchu zakładu górniczego w specjalności górniczej (lub w dziale BHP)',
    patternNote: 'W pozostałych specjalnościach okresy wynoszą zwykle od 12 miesięcy do 5 lat – zależnie od tytułu zawodowego i kierunku. Szczegóły dla Twojej specjalności: tabela A4 (podziemne) lub A5 (zakłady z art. 2 ust. 1).',
    equivalents: ['Stwierdzenie kwalifikacji geofizyka górniczego jest równocześnie stwierdzeniem kwalifikacji do wyższego dozoru w specjalności geofizycznej w podziemnych zakładach (art. 59 ust. 4 Pgg).', 'Kwalifikacje mierniczego / geologa górniczego obejmują wyższy dozór w specjalności mierniczej / geologicznej (art. 59 ust. 2–3 Pgg).'],
    knowledge: ['gornictwo', 'podziemne', 'bhp']
  },
  {
    id: 'pz-kdzial', group: 'podziemne', level: 'Kierownik działu ruchu',
    title: 'Kierownik (i zastępca) działu ruchu – podziemne zakłady górnicze',
    organ: 'OUG', form: 'f1', basis: 'art. 58 ust. 1 pkt 1 Pgg', tables: ['A7', 'A8', 'A9'],
    intro: 'Działy: górniczy, górniczy – przeróbki mechanicznej węgla, techniki strzałowej, tąpań, wentylacji (przewietrzania), energomechaniczny, energomechaniczny ds. obiektów podstawowych, bezpieczeństwa i higieny pracy. Kierownik działu mierniczego / geologicznego musi mieć kwalifikacje mierniczego / geologa górniczego stwierdzone przez Prezesa WUG (art. 58 ust. 3 i 5 Pgg).',
    specs: ['górniczy', 'górniczy – przeróbki mechanicznej węgla', 'techniki strzałowej', 'tąpań', 'wentylacji', 'energomechaniczny', 'energomechaniczny ds. obiektów podstawowych', 'bezpieczeństwa i higieny pracy'],
    pathsTitle: 'Przykład – dział górniczy (tab. A7 lp. 1)',
    paths: [
      { who: 'magister inżynier / inżynier', edu: 'studia: górnictwo', time: '2 lata w wyższym dozorze ruchu pod ziemią (spec. górnicza) albo 5 lat (3 lata w dziale BHP + 2 lata w wyższym dozorze)' },
      { who: 'magister inżynier / inżynier', edu: 'studia podyplomowe: górnictwo podziemne', time: '2 lata w wyższym dozorze albo 5 lat (3 lata BHP + 2 lata wyższy dozór)' }
    ],
    practice: 'praktyka zawodowa pod ziemią w zakresie obejmującym czynności w wyższym dozorze ruchu podziemnego zakładu górniczego',
    patternNote: 'Dział tąpań dopuszcza też studia z geofizyki; dział przeróbki mechanicznej węgla – również magister/licencjat z podyplomowymi „przeróbka mechaniczna węgla” (2 lata). Kierownik działu nie może być technikiem – wymagany tytuł inżyniera lub magistra inżyniera.',
    equivalents: ['Stwierdzenie kwalifikacji kierownika działu jest równocześnie stwierdzeniem kwalifikacji jego zastępcy (art. 59 ust. 1 Pgg).', 'Geofizyk górniczy może być kierownikiem działu tąpań, jeśli odbył praktykę wymaganą dla tych czynności (art. 60 ust. 6 Pgg).'],
    knowledge: ['gornictwo', 'podziemne', 'bhp']
  },
  {
    id: 'pz-kruchu', group: 'podziemne', level: 'Kierownik ruchu zakładu',
    title: 'Kierownik (i zastępca) ruchu – podziemny zakład górniczy',
    organ: 'WUG', form: 'f5', basis: 'art. 58 ust. 2 pkt 1 Pgg', tables: ['A10', 'A11', 'A12'],
    intro: 'Najwyższa funkcja w ruchu zakładu. Kwalifikacje stwierdza Prezes WUG – egzamin pisemny i ustny. Dotyczy kopalń węgla kamiennego i innych kopalin, podziemnego magazynowania substancji i składowania odpadów metodą podziemną, zakładów z art. 2 ust. 1 i podziemnego składowania CO₂.',
    specs: [],
    pathsTitle: 'Wymagania – tab. A10 (podziemne zakłady górnicze)',
    paths: [
      { who: 'magister inżynier', edu: 'studia: górnictwo', time: '2 lata jako kierownik działu ruchu (górniczego, tąpań lub wentylacji)' },
      { who: 'magister inżynier', edu: 'studia: górnictwo', time: '3 lata jako kierownik lub zastępca kierownika działu ruchu (górniczego, tąpań lub wentylacji)' },
      { who: 'inżynier', edu: 'górnictwo + podyplomowe „przewietrzanie i zwalczanie pożarów w zakładach górniczych”', time: '3 lata jako kierownik działu / 4 lata jako kierownik lub zastępca' },
      { who: 'inżynier', edu: 'górnictwo + egzaminy uzupełniające (przewietrzanie i zwalczanie pożarów) zgodnie z programem studiów II stopnia w zakresie górnictwa', time: '3 lata jako kierownik działu / 4 lata jako kierownik lub zastępca' }
    ],
    practice: 'praktyka zawodowa pod ziemią w zakresie obejmującym czynności kierownika (lub zastępcy) działu ruchu podziemnego zakładu górniczego',
    patternNote: 'W zakładach magazynowania/składowania metodą podziemną (A11) i z art. 2 ust. 1 (A12) zaliczana jest praktyka kierownika działu: górniczego, techniki strzałowej, tąpań, wentylacji, energomechanicznego (także ds. obiektów podstawowych), mierniczego lub geologicznego.',
    equivalents: ['Kwalifikacje kierownika ruchu obejmują zastępcę kierownika ruchu (art. 59 ust. 1 Pgg).', 'Osoba z kwalifikacjami kierownika ruchu, która spełnia wymagania kierownika działu, może pełnić funkcję kierownika tego działu (art. 60 ust. 1 Pgg).'],
    knowledge: ['gornictwo', 'podziemne', 'bhp', 'ratownictwo'],
    topics: true
  },

  // ───────────────────────── ODKRYWKOWE ─────────────────────────
  {
    id: 'od-dozor', group: 'odkrywkowe', level: 'Dozór ruchu',
    title: 'Dozór ruchu – odkrywkowe zakłady górnicze',
    organ: 'OUG', form: 'f2', basis: 'art. 58 ust. 1 pkt 3 i 3a Pgg', tables: ['B1', 'B2', 'B3', 'B4'],
    intro: 'Kopalnie odkrywkowe: węgla brunatnego, kruszyw, surowców skalnych (z użyciem lub bez użycia materiałów wybuchowych).',
    specs: ['górnicza', 'wiertnicza', 'geofizyczna', 'energomechaniczna / mechaniczna / elektryczna', 'miernicza', 'geologiczna', 'bezpieczeństwa i higieny pracy', 'ochrona środowiska (tab. B4)', 'budowlana (uprawnienia budowlane + 12 mies., tab. B3)'],
    pathsTitle: 'Przykład – specjalność górnicza (tab. B1 lp. 1, węgiel brunatny / ze środkami strzałowymi)',
    paths: [
      { who: 'magister inżynier / inżynier', edu: 'studia: górnictwo', time: '3 miesiące' },
      { who: 'mgr inż. / mgr / inż. / licencjat', edu: 'studia: geologia górnicza, geologia, geofizyka górnicza lub geofizyka', time: '6 miesięcy' },
      { who: 'mgr inż. / mgr / inż. / licencjat', edu: 'studia podyplomowe: górnictwo odkrywkowe', time: '9 miesięcy' },
      { who: 'technik', edu: TECH('w górnictwie (odkrywkowym)'), time: '12 miesięcy' },
      { who: 'górnik odkrywkowej eksploatacji złóż', edu: 'kwalifikacje zawodowe w zawodzie + praktyka w dozorze na podstawie art. 58 ust. 7 pkt 1 lit. b Pgg w brzmieniu sprzed 28.10.2023 r.', time: '36 miesięcy' }
    ],
    practice: 'praktyka zawodowa w ruchu odkrywkowego zakładu górniczego w danej specjalności',
    patternNote: 'W odkrywkach bez użycia środków strzałowych (tab. B2) schemat jest analogiczny (3–24 miesiące).',
    equivalents: ['Wyższy dozór w odkrywkach uprawnia do funkcji kierownika ruchu w odkrywkach na koncesji starosty (art. 60 ust. 5 Pgg).'],
    knowledge: ['gornictwo', 'odkrywkowe', 'bhp']
  },
  {
    id: 'od-wdozor', group: 'odkrywkowe', level: 'Wyższy dozór ruchu',
    title: 'Wyższy dozór ruchu – odkrywkowe zakłady górnicze',
    organ: 'OUG', form: 'f2', basis: 'art. 58 ust. 1 pkt 3 i 3a Pgg', tables: ['B5', 'B6', 'B7', 'B8'],
    intro: 'Wymagana praktyka w dozorze ruchu odkrywkowego zakładu górniczego w danej specjalności – od 12 miesięcy do 3 lat zależnie od wykształcenia.',
    specs: ['górnicza', 'wiertnicza', 'geofizyczna', 'energomechaniczna / mechaniczna / elektryczna', 'miernicza', 'geologiczna', 'bezpieczeństwa i higieny pracy', 'ochrona środowiska (tab. B8)', 'budowlana (tab. B7)'],
    pathsTitle: null, paths: [],
    practice: 'praktyka zawodowa w zakresie obejmującym czynności w dozorze ruchu odkrywkowego zakładu górniczego',
    patternNote: 'Zakres praktyki: 12–36 miesięcy (tab. B5 i B6). Specjalność ochrona środowiska: 18–36 miesięcy (B8); budowlana: uprawnienia budowlane + 12 miesięcy (B7).',
    equivalents: ['Osoba z kwalifikacjami wyższego dozoru w odkrywkach może być kierownikiem ruchu i kierownikiem działu ruchu w odkrywkach działających na koncesji starosty (art. 60 ust. 5 Pgg).'],
    knowledge: ['gornictwo', 'odkrywkowe', 'bhp']
  },
  {
    id: 'od-kdzial', group: 'odkrywkowe', level: 'Kierownik działu ruchu',
    title: 'Kierownik (i zastępca) działu ruchu – odkrywkowe zakłady górnicze',
    organ: 'OUG', form: 'f2', basis: 'art. 58 ust. 1 pkt 3 i 3a Pgg', tables: ['B9', 'B10', 'B11'],
    intro: 'Działy: górniczy, energomechaniczny, bezpieczeństwa i higieny pracy, ochrona środowiska. Kierownik działu mierniczego / geologicznego – kwalifikacje mierniczego / geologa górniczego (art. 58 ust. 4 i 6 Pgg).',
    specs: ['górniczy', 'energomechaniczny', 'bezpieczeństwa i higieny pracy', 'ochrona środowiska'],
    pathsTitle: 'Przykład – dział górniczy (tab. B9 lp. 1 i B10 lp. 1)',
    paths: [
      { who: 'magister inżynier / inżynier', edu: 'studia: górnictwo', time: '18 miesięcy' },
      { who: 'mgr inż. / mgr / inż. / licencjat', edu: 'geologia górnicza, geologia, geofizyka górnicza, geofizyka', time: '18 miesięcy' },
      { who: 'magister inżynier / inżynier', edu: 'studia podyplomowe: górnictwo odkrywkowe', time: '18 miesięcy' },
      { who: 'technik', edu: TECH('w górnictwie odkrywkowym'), time: '18 miesięcy' }
    ],
    practice: 'praktyka zawodowa w zakresie obejmującym czynności w wyższym dozorze ruchu odkrywkowego zakładu górniczego w specjalności górniczej',
    patternNote: 'Dział BHP: 18 miesięcy, w tym 1 rok w dziale BHP i 6 miesięcy w wyższym dozorze innej specjalności.',
    equivalents: ['Kwalifikacje kierownika działu ruchu w odkrywkach uprawniają do funkcji kierownika (i zastępcy) ruchu w odkrywkach na koncesji starosty (art. 60 ust. 4 Pgg).'],
    knowledge: ['gornictwo', 'odkrywkowe', 'bhp']
  },
  {
    id: 'od-kruchu', group: 'odkrywkowe', level: 'Kierownik ruchu zakładu',
    title: 'Kierownik (i zastępca) ruchu – odkrywkowy zakład górniczy',
    organ: 'OUG', form: 'f2', basis: 'art. 58 ust. 1 pkt 3 i 3a Pgg', tables: ['B12', 'B13'],
    intro: 'W odkrywkach kwalifikacje kierownika ruchu stwierdza dyrektor OUG (egzamin ustny). Uwaga na „skróty” z art. 59–60 Pgg – w wielu małych odkrywkach funkcję kierownika ruchu może pełnić osoba z innymi kwalifikacjami.',
    specs: [],
    pathsTitle: 'Wymagania (tab. B12 i B13)',
    paths: [
      { who: 'magister inżynier / inżynier', edu: 'górnictwo, geologia górnicza, geologia, geofizyka górnicza lub geofizyka', time: '18 miesięcy jako kierownik / zastępca działu górniczego albo 3 lata w wyższym dozorze (spec. górnicza)' },
      { who: 'mgr inż. / mgr / inż. / licencjat', edu: 'automatyka i robotyka, mechanika i budowa maszyn, elektrotechnika, miernictwo górnicze, geodezja (górnicza), geologia (stosowana, górnicza), geoinżynieria, inżynieria geologiczna (+ geofizyka w B13) – z podyplomowymi „górnictwo odkrywkowe”', time: '18 miesięcy jako kierownik / zastępca działu energomechanicznego, mierniczego lub geologicznego albo 3 lata w wyższym dozorze w tych specjalnościach' },
      { who: 'technik', edu: TECH('w górnictwie odkrywkowym'), time: '18 miesięcy jako kierownik / zastępca działu górniczego lub energomechanicznego albo praktyka w wyższym dozorze (szczegóły w tabeli)' }
    ],
    practice: 'praktyka zawodowa w kierownictwie działu ruchu albo w wyższym dozorze ruchu odkrywkowego zakładu górniczego',
    patternNote: null,
    equivalents: ['Mierniczy górniczy i geolog górniczy mogą być kierownikiem ruchu w odkrywkach wydobywających kopaliny BEZ użycia środków strzałowych (art. 59 ust. 2–3 Pgg).', 'Kierownik działu ruchu lub osoba wyższego dozoru w odkrywkach może kierować ruchem odkrywki na koncesji starosty (art. 60 ust. 4–5 Pgg).', 'Osoba z kwalifikacjami kierownika ruchu w otworowych zakładach (węglowodory / inne kopaliny) może pełnić te funkcje w odkrywkach wydobywających kopaliny lecznicze (art. 60 ust. 3 Pgg).'],
    knowledge: ['gornictwo', 'odkrywkowe', 'bhp']
  },

  // ───────────────────────── OTWOROWE / WIERTNICZE ─────────────────────────
  {
    id: 'ot-dozor', group: 'otworowe', level: 'Dozór ruchu',
    title: 'Dozór ruchu – otworowe zakłady górnicze',
    organ: 'OUG', form: 'f3', basis: 'art. 58 ust. 1 pkt 4 Pgg', tables: ['C1', 'C3'],
    intro: 'Zakłady wydobywające ropę naftową, gaz ziemny i inne kopaliny otworami wiertniczymi (np. sól metodą otworową, wody lecznicze, termalne, solanki), podziemne magazyny gazu, składowanie odpadów metodą otworową.',
    specs: ['górnicza', 'geofizyczna', 'energomechaniczna', 'miernicza', 'geologiczna', 'ochrona środowiska', 'bezpieczeństwa i higieny pracy', 'budowlana (uprawnienia budowlane + 12 mies., tab. C3)'],
    pathsTitle: 'Przykład – specjalność górnicza (tab. C1 lp. 1)',
    paths: [
      { who: 'magister inżynier', edu: 'górnictwo, wiertnictwo lub geologia', time: '3 miesiące' },
      { who: 'magister', edu: 'geologia', time: '9 miesięcy' },
      { who: 'inżynier', edu: 'górnictwo, wiertnictwo lub geologia', time: '6 miesięcy' },
      { who: 'licencjat', edu: 'geologia', time: '12 miesięcy' },
      { who: 'magister inżynier / inżynier', edu: 'studia podyplomowe: górnictwo otworowe lub wiertnictwo', time: '6 miesięcy' },
      { who: 'technik', edu: TECH('w górnictwie otworowym lub w wiertnictwie'), time: '12 miesięcy' },
      { who: 'górnik eksploatacji otworowej / wiertacz', edu: 'kwalifikacje zawodowe + praktyka w dozorze na podstawie art. 58 ust. 7 pkt 1 lit. b Pgg w brzmieniu sprzed 28.10.2023 r.', time: '24 miesiące' }
    ],
    practice: 'praktyka zawodowa w ruchu otworowego zakładu górniczego w specjalności górniczej lub w zakładzie wykonującym roboty geologiczne w specjalności wiertniczej',
    patternNote: 'Pozostałe specjalności: geofizyczna (geofizyka 3 mies.; podypl. geofizyka górnicza 6 mies.; technik geofizyk 12 mies.), energomechaniczna (AiR/MiBM/elektrotechnika 3–6 mies.; technik 12 mies.), miernicza (3/6/12 mies.), geologiczna (3–12 mies.), ochrona środowiska (3–12 mies.), BHP (3–12 mies.).',
    equivalents: ['Kwalifikacje w otworowych zakładach (węglowodory / inne kopaliny) pozwalają wykonywać te czynności w odkrywkach wydobywających kopaliny lecznicze (art. 60 ust. 3 Pgg – dotyczy kierownika ruchu, kierownika działu i wyższego dozoru).'],
    knowledge: ['gornictwo', 'otworowe', 'bhp']
  },
  {
    id: 'ot-wiert-dozor', group: 'otworowe', level: 'Dozór ruchu',
    title: 'Dozór ruchu – zakłady wykonujące roboty geologiczne (wiertnicze)',
    organ: 'OUG', form: 'f3', basis: 'art. 58 ust. 1 pkt 4a Pgg', tables: ['C2', 'C3'],
    intro: 'Zakłady wykonujące roboty geologiczne z art. 86 Pgg: wiercenia poszukiwawcze i rozpoznawcze (węglowodory, inne kopaliny, wody podziemne, geotermia, CO₂), roboty z użyciem materiałów wybuchowych lub głębsze niż 100 m. Tu mieszczą się klasyczne „uprawnienia wiertnicze”.',
    specs: ['wiertnicza', 'geofizyczna', 'geofizyki i techniki strzałowej', 'energomechaniczna', 'miernicza', 'geologiczna', 'ochrona środowiska', 'bezpieczeństwa i higieny pracy', 'budowlana (tab. C3)'],
    pathsTitle: 'Przykład – specjalność wiertnicza (tab. C2 lp. 1)',
    paths: [
      { who: 'magister inżynier', edu: 'górnictwo, wiertnictwo lub geologia', time: '3 miesiące' },
      { who: 'magister', edu: 'geologia', time: '9 miesięcy' },
      { who: 'inżynier', edu: 'górnictwo, wiertnictwo lub geologia', time: '6 miesięcy' },
      { who: 'licencjat', edu: 'geologia', time: '12 miesięcy' },
      { who: 'magister inżynier / inżynier', edu: 'studia podyplomowe: górnictwo otworowe lub wiertnictwo', time: '6 miesięcy' },
      { who: 'technik', edu: TECH('w górnictwie otworowym lub w wiertnictwie'), time: '12 miesięcy' },
      { who: 'górnik eksploatacji otworowej / wiertacz', edu: 'kwalifikacje zawodowe + praktyka w dozorze na podstawie art. 58 ust. 7 pkt 1 lit. b Pgg w brzmieniu sprzed 28.10.2023 r.', time: '24 miesiące' }
    ],
    practice: 'praktyka zawodowa w ruchu otworowego zakładu górniczego w specjalności górniczej lub w zakładzie wykonującym roboty geologiczne w specjalności wiertniczej',
    patternNote: 'Specjalność geofizyki i techniki strzałowej (C2 lp. 3): górnictwo / wiertnictwo / geofizyka / geologia – mgr 3 mies., inż. lub licencjat z podyplomowymi „geofizyka i technika strzałowa” 6 mies., technik 12 mies.',
    equivalents: ['Kwalifikacje w zakładzie z art. 58 ust. 1 pkt 4a uprawniają też do analogicznych funkcji w pozostałych zakładach wykonujących roboty geologiczne (art. 58 ust. 10 Pgg).'],
    knowledge: ['gornictwo', 'otworowe', 'geologia', 'bhp']
  },
  {
    id: 'ot-wdozor', group: 'otworowe', level: 'Wyższy dozór ruchu',
    title: 'Wyższy dozór ruchu – otworowe zakłady górnicze i roboty geologiczne',
    organ: 'OUG', form: 'f3', basis: 'art. 58 ust. 1 pkt 4 i 4a Pgg', tables: ['C4', 'C5', 'C6'],
    intro: 'Wymagana praktyka w dozorze ruchu otworowego zakładu górniczego lub zakładu wykonującego roboty geologiczne.',
    specs: ['górnicza / wiertnicza', 'geofizyczna', 'geofizyki i techniki strzałowej', 'energomechaniczna', 'miernicza', 'geologiczna', 'ochrona środowiska', 'bezpieczeństwa i higieny pracy', 'budowlana (tab. C6)'],
    pathsTitle: 'Przykład – specjalność górnicza / wiertnicza (tab. C4 lp. 1)',
    paths: [
      { who: 'magister inżynier', edu: 'górnictwo, wiertnictwo lub geologia', time: '18 miesięcy' },
      { who: 'magister', edu: 'geologia', time: '2 lata' },
      { who: 'inżynier', edu: 'górnictwo, wiertnictwo lub geologia', time: '30 miesięcy' },
      { who: 'licencjat', edu: 'geologia', time: '30 miesięcy' },
      { who: 'magister inżynier / inżynier', edu: 'studia podyplomowe: górnictwo otworowe lub wiertnictwo', time: '30 miesięcy' },
      { who: 'technik', edu: TECH('w górnictwie otworowym lub w wiertnictwie'), time: '3 lata' }
    ],
    practice: 'praktyka zawodowa w zakresie obejmującym czynności w dozorze ruchu otworowego zakładu górniczego (spec. górnicza) lub zakładu wykonującego roboty geologiczne (spec. wiertnicza)',
    patternNote: 'Geofizyczna: geofizyka 18 mies., podypl. geofizyka górnicza 2 lata, technik geofizyk 3 lata. Energomechaniczna: 18 mies. / 2 lata / technik 3 lata. Miernicza: mgr inż. 12 mies., inż. 2 lata, technik geodeta 3 lata.',
    equivalents: [],
    knowledge: ['gornictwo', 'otworowe', 'bhp']
  },
  {
    id: 'ot-kdzial', group: 'otworowe', level: 'Kierownik działu ruchu',
    title: 'Kierownik (i zastępca) działu ruchu – otworowe zakłady górnicze i roboty geologiczne',
    organ: 'OUG', form: 'f3', basis: 'art. 58 ust. 1 pkt 4 i 4a Pgg', tables: ['C7', 'C8'],
    intro: 'Działy w otworowych zakładach: górniczy, energomechaniczny, BHP. W zakładach robót geologicznych: wiertniczy, geofizyki i techniki strzałowej, energomechaniczny, BHP (oraz ochrona środowiska). Kierownik działu mierniczego / geologicznego – kwalifikacje mierniczego / geologa górniczego.',
    specs: ['wiertniczy', 'geofizyki i techniki strzałowej', 'górniczy', 'energomechaniczny', 'bezpieczeństwa i higieny pracy', 'ochrona środowiska'],
    pathsTitle: 'Przykład – dział wiertniczy (tab. C8 lp. 1)',
    paths: [
      { who: 'magister inżynier', edu: 'górnictwo lub wiertnictwo', time: '12 miesięcy' },
      { who: 'inżynier', edu: 'górnictwo lub wiertnictwo', time: '16 miesięcy' },
      { who: 'magister inżynier / inżynier', edu: 'studia podyplomowe: górnictwo otworowe lub wiertnictwo', time: '18 miesięcy' },
      { who: 'technik', edu: TECH('w górnictwie otworowym lub w wiertnictwie'), time: '2 lata' }
    ],
    practice: 'praktyka zawodowa w zakresie obejmującym czynności w wyższym dozorze ruchu otworowego zakładu górniczego (spec. górnicza) lub zakładu wykonującego roboty geologiczne (spec. wiertnicza)',
    patternNote: 'Dział geofizyki i techniki strzałowej: górnictwo / wiertnictwo / geofizyka 12–16 mies., podyplomowe 18 mies., technik 2 lata. Energomechaniczny: 18 mies. / technik 2 lata. BHP: 18 mies. (w tym 1 rok w dziale BHP).',
    equivalents: ['Geofizyk górniczy (podziemne) może być kierownikiem działu geofizyka i technika strzałowa w zakładach robót geologicznych (węglowodory i inne kopaliny), jeśli ma wymaganą praktykę (art. 60 ust. 6 Pgg).'],
    knowledge: ['gornictwo', 'otworowe', 'bhp']
  },
  {
    id: 'ot-kruchu', group: 'otworowe', level: 'Kierownik ruchu zakładu',
    title: 'Kierownik (i zastępca) ruchu – otworowy zakład górniczy / zakład robót geologicznych',
    organ: 'OUG', form: 'f3', basis: 'art. 58 ust. 1 pkt 4 i 4a Pgg', tables: ['C9', 'C10'],
    intro: 'Kwalifikacje stwierdza dyrektor OUG. Wyjątek: kierownik ruchu zakładu prowadzącego podziemne składowanie dwutlenku węgla – Prezes WUG (art. 58 ust. 2 pkt 1 lit. e Pgg).',
    specs: [],
    pathsTitle: 'Wymagania – zakład wykonujący roboty geologiczne (tab. C10)',
    paths: [
      { who: 'magister inżynier / inżynier', edu: 'górnictwo lub wiertnictwo', time: '12 miesięcy jako kierownik / zastępca działu wiertniczego albo 2 lata w wyższym dozorze (spec. wiertnicza)' },
      { who: 'mgr inż. / mgr / inż. / licencjat', edu: 'AiR, MiBM, elektrotechnika, geologia (górnicza, stosowana), geoinżynieria, inżynieria geologiczna, geofizyka – z podyplomowymi „górnictwo otworowe” lub „wiertnictwo”', time: '18 miesięcy jako kierownik / zastępca działu (geofizyki i techniki strzałowej, energomechanicznego, geologicznego) albo 3 lata w wyższym dozorze' },
      { who: 'magister inżynier / inżynier', edu: 'studia podyplomowe: górnictwo otworowe lub wiertnictwo', time: '18 miesięcy jako kierownik / zastępca działu albo 3 lata w wyższym dozorze' },
      { who: 'technik', edu: TECH('w górnictwie otworowym lub w wiertnictwie'), time: '4 lata jako kierownik / zastępca działu ruchu (wiertniczego, energomechanicznego lub geologicznego)' }
    ],
    practice: 'praktyka w kierownictwie działu ruchu albo w wyższym dozorze ruchu',
    patternNote: 'Otworowe zakłady górnicze (tab. C9): analogicznie – 12 mies. jako kierownik działu górniczego albo 2 lata wyższego dozoru (górnictwo/wiertnictwo); 18 mies. / 3 lata dla pozostałych kierunków z podyplomowymi; technik – 4 lata wyższego dozoru.',
    equivalents: ['Geolog górniczy może być kierownikiem ruchu w zakładach wydobywających wody lecznicze, termalne i solanki (art. 59 ust. 3 Pgg).', 'Geofizyk górniczy (zał. 4) – zakres wiedzy obejmuje m.in. kierownika ruchu w zakładach robót geologicznych bez środków strzałowych do 100 m (art. 54 pkt 1 lit. d Pgg).'],
    knowledge: ['gornictwo', 'otworowe', 'geologia', 'bhp']
  },

  // ───────────────────────── BUDOWLANA / OCHRONA ŚRODOWISKA / MAGAZYNY ─────────────────────────
  {
    id: 'bo', group: 'inne-oug', level: 'Dozór / wyższy dozór / kierownik działu',
    title: 'Specjalności budowlana i ochrona środowiska; magazynowanie substancji i składowanie odpadów',
    organ: 'OUG', form: 'f4', basis: 'art. 58 ust. 1 pkt 10 Pgg', tables: ['A3', 'A6', 'B3', 'B4', 'B7', 'B8', 'B11', 'C3', 'C6', 'D1', 'D2', 'D3', 'D4', 'D5'],
    intro: 'Kierownik działu ruchu ochrona środowiska oraz dozór i wyższy dozór w specjalnościach budowlanej i ochrona środowiska – we wszystkich rodzajach zakładów (podziemne, odkrywkowe, otworowe, magazynowanie, składowanie odpadów, art. 2 ust. 1, roboty geologiczne).',
    specs: ['budowlana', 'ochrona środowiska', 'kierownik działu ruchu ochrona środowiska'],
    pathsTitle: 'Najważniejsze wymagania',
    paths: [
      { who: 'specjalność budowlana – dozór', edu: 'uprawnienia budowlane w specjalności określonej w Prawie budowlanym', time: '6 miesięcy (podziemne, magazyny) / 12 miesięcy (odkrywki, otwory)' },
      { who: 'specjalność budowlana – wyższy dozór', edu: 'uprawnienia budowlane', time: '12 miesięcy praktyki budowlanej w dozorze' },
      { who: 'ochrona środowiska – dozór', edu: 'inżynieria / ochrona środowiska; albo górnictwo, geologia, geofizyka, leśnictwo, ogrodnictwo (+ podypl. ochrona środowiska); technik ochrony środowiska', time: '3 / 6 / 12 miesięcy' },
      { who: 'ochrona środowiska – wyższy dozór', edu: 'jw.', time: '18–36 miesięcy w dozorze' },
      { who: 'kierownik działu ruchu ochrona środowiska', edu: 'inżynieria / ochrona środowiska lub inne kierunki z podyplomowymi', time: '18 miesięcy w wyższym dozorze (spec. ochrona środowiska)' }
    ],
    practice: 'praktyka budowlana / praktyka w specjalności ochrona środowiska w ruchu zakładu górniczego lub zakładu',
    patternNote: 'W zakładach podziemnego składowania CO₂ kwalifikacje w tych specjalnościach stwierdza Prezes WUG (art. 58 ust. 2 pkt 2 Pgg).',
    equivalents: [],
    knowledge: ['gornictwo', 'bhp']
  },

  // ───────────────────────── PREZES WUG: MIERNICZY / GEOLOG / GEOFIZYK / RATOWNICTWO ─────────────────────────
  {
    id: 'mierniczy', group: 'wug', level: 'Mierniczy górniczy',
    title: 'Mierniczy górniczy',
    organ: 'WUG', form: 'f5', basis: 'art. 58 ust. 2 pkt 3 Pgg', tables: ['Z2'],
    intro: 'Dwa zakresy: (a) zakłady górnicze, zakłady z art. 2 ust. 1 i zakłady robót geologicznych (pełny – także podziemne), albo (b) zakłady górnicze inne niż podziemne oraz zakłady robót geologicznych.',
    specs: ['zakres pełny (z podziemnymi) – tab. 1', 'zakres bez zakładów podziemnych – tab. 2'],
    pathsTitle: 'Wymagania (zał. nr 2, tab. 1 i 2 – identyczne okresy)',
    paths: [
      { who: 'magister inżynier', edu: 'kierunek górnictwo i geologia lub geodezja i kartografia; specjalność geodezja górnicza lub miernictwo górnicze; przedmioty: geodezja górnicza, górnictwo i ochrona terenów górniczych', time: '2 lata' },
      { who: 'magister inżynier', edu: 'geodezja i kartografia, specjalność geodezja + egzaminy uzupełniające (geodezja górnicza, górnictwo i ochrona terenów górniczych – wg programu specjalności geodezja górnicza)', time: '3 lata' },
      { who: 'inżynier', edu: 'jak w pkt 1 (górnictwo i geologia / geodezja i kartografia, spec. geodezja górnicza lub miernictwo górnicze)', time: '3 lata' },
      { who: 'inżynier', edu: 'geodezja i kartografia, spec. geodezja + egzaminy uzupełniające', time: '4 lata' }
    ],
    practice: 'praktyka miernicza, w tym co najmniej połowa pod ziemią w ruchu podziemnego zakładu górniczego (tab. 1) albo w odkrywkowym / otworowym zakładzie górniczym (tab. 2)',
    patternNote: 'Do wniosku: opinia o przebiegu pracy zawodowej podpisana przez kierownika działu mierniczego oraz zgoda na korespondencję elektroniczną (zalecenie WUG).',
    equivalents: ['Kwalifikacje mierniczego górniczego są równocześnie kwalifikacjami: kierownika (i zastępcy) ruchu w odkrywkach bez środków strzałowych, kierownika (i zastępcy) działu mierniczego, wyższego dozoru w specjalności mierniczej (art. 59 ust. 2 Pgg).'],
    knowledge: ['mierniczy', 'gornictwo'],
    questions: 'mierniczy'
  },
  {
    id: 'geolog-gorn', group: 'wug', level: 'Geolog górniczy',
    title: 'Geolog górniczy',
    organ: 'WUG', form: 'f5', basis: 'art. 58 ust. 2 pkt 4 Pgg', tables: ['Z3'],
    intro: 'Dwa zakresy: (a) zakłady górnicze, zakłady z art. 2 ust. 1 i zakłady robót geologicznych (pełny), albo (b) zakłady górnicze inne niż podziemne oraz zakłady robót geologicznych. Nie mylić z „kwalifikacjami geologicznymi” kat. I–XIII (Minister KiŚ).',
    specs: ['zakres pełny (z podziemnymi) – tab. 1', 'zakres bez zakładów podziemnych – tab. 2'],
    pathsTitle: 'Wymagania (zał. nr 3, tab. 1 i 2 – identyczne okresy)',
    paths: [
      { who: 'magister inżynier', edu: 'górnictwo i geologia lub geologia stosowana; specjalność geologia górnicza lub geologia stosowana; przedmioty: geologia górnicza, hydrogeologia, górnictwo i wiertnictwo', time: '2 lata' },
      { who: 'magister inżynier / magister', edu: 'górnictwo i geologia, geologia, geofizyka, inżynieria geologiczna (spec. geologia, geoinżynieria, geofizyka) + egzaminy uzupełniające: geologia górnicza, górnictwo i wiertnictwo; hydrogeologia', time: '3 lata' },
      { who: 'inżynier', edu: 'jak w pkt 1', time: '3 lata' },
      { who: 'inżynier / licencjat', edu: 'jak w pkt 2 + egzaminy uzupełniające', time: '4 lata' }
    ],
    practice: 'praktyka geologiczna, w tym co najmniej połowa pod ziemią w ruchu podziemnego zakładu górniczego (tab. 1) albo w odkrywkowym / otworowym zakładzie górniczym (tab. 2)',
    patternNote: 'Do wniosku: opinia o przebiegu pracy zawodowej podpisana przez kierownika działu geologicznego.',
    equivalents: ['Kwalifikacje geologa górniczego są równocześnie kwalifikacjami: kierownika (i zastępcy) ruchu w odkrywkach bez środków strzałowych i w zakładach wydobywających wody lecznicze, termalne i solanki, kierownika (i zastępcy) działu geologicznego, wyższego dozoru w specjalności geologicznej (art. 59 ust. 3 Pgg).'],
    knowledge: ['geolog', 'gornictwo'],
    questions: 'geolog'
  },
  {
    id: 'geofizyk', group: 'wug', level: 'Geofizyk górniczy',
    title: 'Geofizyk górniczy',
    organ: 'WUG', form: 'f5', basis: 'art. 58 ust. 2 pkt 5 Pgg', tables: ['Z4'],
    intro: 'Geofizyka górnicza w podziemnych zakładach (m.in. obsługa zagrożenia tąpaniami, sejsmometria).',
    specs: [],
    pathsTitle: 'Wymagania (zał. nr 4)',
    paths: [
      { who: 'magister inżynier / magister', edu: 'geofizyka', time: '2 lata' },
      { who: 'magister inżynier / magister', edu: 'górnictwo, geologia górnicza lub geologia + egzaminy uzupełniające: grawimetria, magnetometria, geofizyka otworowa, metody sejsmiczne, metody elektryczne i elektromagnetyczne (program studiów z geofizyki)', time: '3 lata' },
      { who: 'inżynier / licencjat', edu: 'geofizyka', time: '3 lata' },
      { who: 'inżynier / licencjat', edu: 'górnictwo, geologia górnicza lub geologia + egzaminy uzupełniające jw.', time: '4 lata' }
    ],
    practice: 'praktyka geofizyczna w ruchu zakładu górniczego lub zakładu',
    patternNote: null,
    equivalents: ['Równocześnie kwalifikacje do wyższego dozoru w specjalności geofizycznej w podziemnych zakładach (art. 59 ust. 4 Pgg).', 'Może pełnić funkcję kierownika (i zastępcy) działu tąpań oraz działu geofizyka i technika strzałowa w zakładach robót geologicznych, a także wyższy dozór w specjalności geofizyka i technika strzałowa – po odbyciu praktyki wymaganej dla tych czynności (art. 60 ust. 6 Pgg).'],
    knowledge: ['gornictwo', 'podziemne'],
    questions: null
  },
  {
    id: 'ratownictwo', group: 'wug', level: 'Ratownictwo górnicze',
    title: 'Kierownictwo w podmiotach zawodowo trudniących się ratownictwem górniczym',
    organ: 'WUG', form: 'f5', basis: 'art. 58 ust. 2 pkt 6–7 Pgg', tables: ['Z5'],
    intro: 'Np. CSRG i jej okręgowe stacje: kierownik jednostki ratownictwa górniczego i zastępca, kierownik okręgowej stacji ratownictwa górniczego i zastępca, kierownik dyżurujących zawodowych zastępów ratowniczych, kierownik zawodowych pogotowi specjalistycznych, kierownik oddziału terenowego JRG (zakłady inne niż podziemne).',
    specs: ['podmioty dla zakładów podziemnych (część A)', 'podmioty dla zakładów innych niż podziemne (część B)'],
    pathsTitle: 'Wymagania – część A (zakłady podziemne)',
    paths: [
      { who: 'Kierownik dyżurujących zawodowych zastępów / pogotowi specjalistycznych', edu: 'mgr inż. / inż. górnictwo lub podyplomowe górnictwo podziemne', time: '3 lata w (wyższym) dozorze ruchu podziemnego + 3 lata w służbach ratownictwa przedsiębiorcy – albo 3 lata jako zawodowy ratownik górniczy w podmiocie' },
      { who: 'jw. – technik', edu: TECH('w górnictwie podziemnym'), time: '5 lat w (wyższym) dozorze + 5 lat w służbach ratownictwa – albo 5 lat jako zawodowy ratownik górniczy' },
      { who: 'Kierownik okręgowej stacji ratownictwa górniczego (i zastępca)', edu: 'mgr inż. / inż. górnictwo lub podyplomowe górnictwo podziemne', time: '4 lata w dozorze i wyższym dozorze (w tym 1 rok w wyższym dozorze) + 3 lata praktyki ratowniczej – albo 3 lata jako kierownik dyżurujących zastępów / pogotowi w podmiocie' },
      { who: 'Kierownik jednostki ratownictwa górniczego (i zastępca)', edu: 'mgr inż. / inż. górnictwo lub podyplomowe górnictwo podziemne', time: '5 lat w kierownictwie i wyższym dozorze (w tym 2 lata w kierownictwie ruchu) + 5 lat praktyki ratowniczej – albo 5 lat jako kierownik OSRG, jego zastępca, kierownik zastępów lub pogotowi' }
    ],
    practice: 'praktyka zawodowa w ruchu zakładu górniczego oraz praktyka ratownicza (w służbach ratownictwa przedsiębiorcy lub jako zawodowy ratownik górniczy)',
    patternNote: 'Część B (zakłady inne niż podziemne): wymagane studia lub podyplomowe z górnictwa albo wiertnictwa; 3 lata wyższego dozoru + 3 lata praktyki ratowniczej (kierownik oddziału terenowego / pogotowi), technik – 5 + 5 lat; kierownik JRG – 5 + 5 lat.',
    equivalents: ['Kwalifikacje kierownika JRG i kierownika OSRG obejmują ich zastępców (art. 59 ust. 1 pkt 3–4 Pgg).'],
    knowledge: ['ratownictwo', 'podziemne', 'gornictwo'],
    questions: null,
    ratTopics: true
  },

  // ───────────────────────── CZYNNOŚCI SPECJALISTYCZNE ─────────────────────────
  {
    id: 'specjalistyczne', group: 'inne', level: 'Czynności specjalistyczne',
    title: 'Czynności specjalistyczne w ruchu zakładu górniczego',
    organ: 'PRAC', form: null, basis: 'art. 53 ust. 5, art. 56, art. 58 ust. 11 Pgg', tables: ['Z6'],
    intro: 'Bez egzaminu przed urzędem górniczym. Pracodawca sprawdza spełnienie wymagań art. 56 Pgg i zał. nr 6 do rozporządzenia (wykształcenie, praktyka, aktualne zaświadczenia z kursów specjalistycznych, badania psychologiczne, minimalny wiek), wystawia zaświadczenie i przechowuje je w aktach osobowych.',
    specs: ['Podziemne: górnik strzałowy, wydawca środków strzałowych, sygnalista szybowy, maszynista maszyn wyciągowych, rewident urządzeń wyciągowych, operator kombajnów ścianowych/chodnikowych, maszyn do robót strzałowych, pojazdów do przewozu osób lub środków strzałowych, maszynista lokomotyw / kolejek podwieszanych / spągowych, rewident urządzeń łączności i alarmowania, elektromonter do 1 kV i powyżej 1 kV', 'Odkrywkowe: strzałowy, wydawca środków strzałowych', 'Otworowe / CO₂: strzałowy, wydawca środków strzałowych, operator agregatów cementacyjnych, zasobników i urządzeń do intensyfikacji wydobycia, elektromonter do 1 kV i powyżej 1 kV'],
    pathsTitle: 'Wymagania ogólne (art. 56 Pgg)',
    paths: [
      { who: 'Wykształcenie', edu: 'szkoła średnia / średnia branżowa albo szkoła ponadpodstawowa + tytuł zawodowy lub kwalifikacje w zawodzie', time: '—' },
      { who: 'Praktyka', edu: 'staż pracy lub okres szkolenia praktycznego na stanowisku – wg zał. nr 6', time: 'wg zał. nr 6' },
      { who: 'Kursy', edu: 'aktualne zaświadczenia o odbyciu kursów specjalistycznych (z okresami ważności)', time: 'wg zał. nr 6' },
      { who: 'Badania psychologiczne', edu: 'dla czynności z art. 53 ust. 5 pkt 1 lit. c–j i pkt 3 lit. c–e (zagadnienia: § 8 rozporządzenia)', time: '—' },
      { who: 'Strzałowi i wydawcy', edu: 'orzeczenia lekarskie i psychologiczne wg ustawy o materiałach wybuchowych do użytku cywilnego', time: '—' }
    ],
    practice: 'zał. nr 6 do rozporządzenia (tabele 1–3)',
    patternNote: 'W stanie nadzwyczajnym, zagrożenia epidemicznego lub epidemii ważność okresowych kursów upływająca w tym czasie przedłuża się do 90 dni od zniesienia stanu (§ 7 ust. 2 rozporządzenia).',
    equivalents: [],
    knowledge: ['bhp', 'gornictwo'],
    questions: null
  },

  // ───────────────────────── KWALIFIKACJE GEOLOGICZNE ─────────────────────────
  {
    id: 'geologia-I-IX', group: 'geologia', level: 'Geolog – kat. I–IX',
    title: 'Kwalifikacje w zawodzie geolog – kategorie I–IX',
    organ: 'MKIS', form: null, basis: 'art. 50–52 Pgg; rozp. MKiŚ z 11.02.2026 (Dz.U. 2026 poz. 249)', tables: [],
    intro: 'Wykonywanie, dozorowanie i kierowanie pracami geologicznymi. Świadectwo wydaje minister właściwy do spraw środowiska. Uwaga: od 17.03.2026 obowiązuje nowe rozporządzenie (Dz.U. 2026 poz. 249) – do wniosków złożonych wcześniej stosuje się przepisy dotychczasowe.',
    specs: ['I – poszukiwanie i rozpoznawanie złóż węglowodorów', 'II – złoża kopalin objętych własnością górniczą (bez ropy, gazu, wód leczniczych, termalnych i solanek) oraz złoża objęte prawem własności nieruchomości', 'III – złoża kopalin objętych prawem własności nieruchomości gruntowej', 'IV – wody podziemne (w tym lecznicze, termalne, solanki), warunki hydrogeologiczne, ciepło Ziemi, otwory obserwacyjne', 'V – wody podziemne (bez leczniczych, termalnych i solanek), warunki hydrogeologiczne, ciepło Ziemi', 'VI – warunki geologiczno-inżynierskie (w tym obiekty zakładów górniczych, budownictwo wodne, magazynowanie, składowanie, CO₂)', 'VII – warunki geologiczno-inżynierskie (bez obiektów zakładów górniczych i budownictwa wodnego)', 'VIII – kartografia geologiczna', 'IX – badania sejsmiczne i geofizyka wiertnicza (także ze środkami strzałowymi)'],
    pathsTitle: 'Wykształcenie i praktyka (§ 2–3 rozp. 2026)',
    paths: [
      { who: 'Kat. I–VII', edu: 'studia I/II stopnia lub jednolite na kierunku geologicznym', time: '2 lata przy sporządzaniu projektów robót geologicznych i dokumentacji geologicznych' },
      { who: 'Kat. I–VII', edu: 'inne studia z ≥ 2 przedmiotami z zakresu kategorii (≥ 6 ECTS lub ≥ 60 godz.) + dwusemestralne podyplomowe z zakresu kategorii', time: '2 lata' },
      { who: 'Kat. I–VII', edu: 'jw. bez właściwych studiów podyplomowych', time: '3 lata' },
      { who: 'Kat. VIII', edu: 'geologia lub geografia (albo inne studia jw.)', time: '2 lata (3 lata bez podyplomowych) przy projektowaniu i dokumentowaniu prac kartografii geologicznej' },
      { who: 'Kat. IX', edu: 'geologia lub geofizyka (albo inne studia z ≥ 2 przedmiotami z zakresu kategorii + właściwe podyplomowe)', time: '2 lata przy projektowaniu i dokumentowaniu badań geofizycznych' },
      { who: 'Kat. IX', edu: 'fizyka, albo inne studia bez właściwych podyplomowych', time: '3 lata' }
    ],
    practice: 'udział w sporządzaniu określonej liczby projektów robót geologicznych i dokumentacji (np. kat. II: 2 projekty + 3 dokumentacje złóż; kat. IV/V: 3 projekty + 7 dokumentacji hydrogeologicznych; kat. VI/VII: 3 projekty + 7 dokumentacji geologiczno-inżynierskich) oraz min. 3 miesiące dozoru prac geologicznych lub kierowania robotami w terenie (§ 4 rozp.)',
    patternNote: 'Bez właściwych studiów podyplomowych liczby opracowań są wyższe (np. 4 projekty + 10 dokumentacji). Praktykę można zacząć po 4. semestrze studiów I stopnia; odbywa się ją pod nadzorem osoby z kwalifikacjami (art. 52 ust. 5–7 Pgg). Do wniosku dołącza się wykaz opracowań potwierdzony przez zleceniodawcę lub archiwum geologiczne (art. 61 ust. 3 pkt 2 Pgg).',
    equivalents: ['Kat. I–VIII upoważniają do prac dotyczących regionalnych badań budowy geologicznej kraju i otworów do rozpoznania głębokiego podłoża (art. 50 ust. 3 Pgg).', 'Kat. VI i VII obejmują badania potencjału termalnego gruntów i skał (art. 50 ust. 4 Pgg).'],
    knowledge: ['geologia'],
    questions: null,
    geoExam: true
  },
  {
    id: 'geologia-XIII', group: 'geologia', level: 'Geolog – kat. XIII',
    title: 'Kwalifikacje w zawodzie geolog – kategoria XIII (dozór geologiczny)',
    organ: 'MARSZ', form: null, basis: 'art. 50 ust. 2 pkt 13, art. 51 pkt 2 Pgg; § 2 pkt 4 i § 3 ust. 1 pkt 4 rozp. 2026', tables: [],
    intro: 'Dozór geologiczny nad pracami geologicznymi (bez badań geofizycznych z kat. IX) oraz kierowanie w terenie robotami geologicznymi poza obszarem górniczym, bez środków strzałowych lub do głębokości 100 m – np. dozór przy wierceniach studni, pomp ciepła, badaniach geotechnicznych.',
    specs: ['Marszałek dolnośląski: woj. dolnośląskie, lubuskie, opolskie, wielkopolskie', 'Marszałek małopolski: woj. małopolskie, podkarpackie, śląskie, świętokrzyskie', 'Marszałek mazowiecki: woj. lubelskie, łódzkie, mazowieckie, podlaskie', 'Marszałek pomorski: woj. kujawsko-pomorskie, pomorskie, warmińsko-mazurskie, zachodniopomorskie'],
    pathsTitle: 'Wymagania',
    paths: [
      { who: 'Technik', edu: 'świadectwo dojrzałości + dyplom w zawodzie: technik geolog, technik górnik, technik górnictwa otworowego, technik górnictwa podziemnego, technik podziemnej eksploatacji kopalin innych niż węgiel kamienny, technik górnictwa odkrywkowego lub technik wiertnik', time: 'co najmniej 1 rok' },
      { who: 'Absolwent studiów', edu: 'studia I/II stopnia lub jednolite na kierunku geologicznym', time: 'co najmniej 1 rok' }
    ],
    practice: 'praktyka przy wykonywaniu dozoru prac geologicznych lub kierowaniu w terenie robotami geologicznymi (poza obszarem górniczym, bez środków strzałowych albo do 100 m)',
    patternNote: 'Właściwość marszałka zależy od miejsca zamieszkania lub miejsca wykonywania czynności.',
    equivalents: [],
    knowledge: ['geologia'],
    questions: null,
    geoExam: true
  },

  // ───────────────────────── UZNAWANIE ─────────────────────────
  {
    id: 'uznawanie', group: 'inne', level: 'Kwalifikacje zagraniczne',
    title: 'Uznanie kwalifikacji nabytych za granicą (UE / EFTA / Szwajcaria / Ukraina)',
    organ: 'WUG', form: 'f6', basis: 'ustawa z 22.12.2015 o zasadach uznawania kwalifikacji zawodowych (Dz.U. 2023 poz. 334); art. 23b ustawy o pomocy obywatelom Ukrainy; rozp. MAP z 31.05.2023 (Dz.U. 2023 poz. 1061)',
    tables: [],
    intro: 'Uznawanie kwalifikacji do wykonywania górniczych zawodów regulowanych nabytych w państwach UE, EFTA (EOG), Szwajcarii lub na Ukrainie. Postępowanie kończy się decyzją; może zostać nałożony staż adaptacyjny albo test umiejętności.',
    specs: [],
    pathsTitle: null, paths: [],
    practice: '—',
    patternNote: 'Opłata za przeprowadzenie postępowania i wydanie decyzji w 2026 r.: 1682,10 zł (35% minimalnego wynagrodzenia).',
    equivalents: [],
    knowledge: ['gornictwo'],
    questions: null
  }
];

window.GROUPS = [
  { id: 'podziemne', name: 'Górnictwo podziemne', icon: 'pickaxe', desc: 'Kopalnie węgla, rud, soli; zakłady z art. 2 ust. 1 Pgg' },
  { id: 'odkrywkowe', name: 'Górnictwo odkrywkowe', icon: 'mountain', desc: 'Węgiel brunatny, kruszywa, surowce skalne' },
  { id: 'otworowe', name: 'Otworowe i wiertnicze', icon: 'drill', desc: 'Ropa, gaz, solanki, wody termalne, roboty geologiczne' },
  { id: 'inne-oug', name: 'Budowlana i ochrona środowiska', icon: 'leaf', desc: 'Specjalności z art. 58 ust. 1 pkt 10 Pgg' },
  { id: 'wug', name: 'Prezes WUG', icon: 'shield', desc: 'Mierniczy, geolog, geofizyk górniczy, ratownictwo' },
  { id: 'geologia', name: 'Kwalifikacje geologiczne', icon: 'layers', desc: 'Geolog kat. I–IX i XIII' },
  { id: 'inne', name: 'Pozostałe', icon: 'more', desc: 'Czynności specjalistyczne, uznawanie kwalifikacji' }
];

// Procedura – górnictwo i ratownictwo (OUG / WUG)
window.PROCEDURE = [
  { id: 's1', title: 'Ustal właściwą kwalifikację i organ', body: 'Określ rodzaj zakładu (podziemny, odkrywkowy, otworowy, roboty geologiczne), poziom (dozór, wyższy dozór, kierownik działu, kierownik ruchu) i specjalność. Na tej podstawie wybierz organ: dyrektor OUG (art. 58 ust. 1 Pgg) albo Prezes WUG (art. 58 ust. 2 Pgg). Skorzystaj z kreatora w aplikacji.', law: 'art. 58, art. 61 ust. 2a Pgg' },
  { id: 's2', title: 'Sprawdź wymagania: wykształcenie i praktyka', body: 'Odszukaj w załączniku do rozporządzenia z 2024 r. tabelę dla swojej kwalifikacji. Porównaj tytuł zawodowy, kierunek/specjalność studiów (lub studia podyplomowe, egzaminy uzupełniające, kwalifikacje technika) oraz wymagany czas i rodzaj praktyki. Praktyka może być odbyta również przed uzyskaniem wykształcenia (art. 55 ust. 1 Pgg).', law: 'art. 54 pkt 3–4, art. 55, art. 57 Pgg' },
  { id: 's3', title: 'Zbierz dokumenty', body: 'Dyplom (odpis lub uwierzytelniona kopia), suplement / wykaz przedmiotów, świadectwa studiów podyplomowych, zaświadczenia o egzaminach uzupełniających, świadectwa pracy, zaświadczenia o zatrudnieniu, opinia o przebiegu pracy zawodowej. Jeśli dołączasz oryginały – zostaną zwrócone najpóźniej w dniu egzaminu.', law: 'art. 61 ust. 3 Pgg' },
  { id: 's4', title: 'Wypełnij i złóż wniosek', body: 'Użyj właściwego formularza WUG (1–5). Wniosek zawiera: imię i nazwisko, PESEL, serię i nr dowodu, adres, wskazaną kwalifikację (z uwzględnieniem art. 58 ust. 1 lub 2), wykształcenie, ew. studia podyplomowe / tytuł zawodowy / egzaminy uzupełniające, opis doświadczenia zawodowego. Podaj telefon i e-mail – przyspiesza wyjaśnienia.', law: 'art. 61 ust. 1–2 Pgg' },
  { id: 's5', title: 'Weryfikacja wniosku', body: 'Organ sprawdza kompletność (ew. wezwanie do uzupełnienia braków) i spełnienie wymagań. Dopuszcza do egzaminu albo odmawia w drodze decyzji. Od decyzji Prezesa WUG – wniosek o ponowne rozpatrzenie w 14 dni albo skarga do WSA w Gliwicach w 30 dni (wpis 200 zł). Od decyzji dyrektora OUG przysługuje odwołanie na zasadach KPA – pouczenie znajdziesz w decyzji.', law: 'art. 62 Pgg; KPA' },
  { id: 's6', title: 'Zawiadomienie o terminie egzaminu', body: 'Komisja egzaminacyjna zawiadamia pisemnie o terminie i miejscu co najmniej 14 dni przed egzaminem (u Prezesa WUG – także elektronicznie, po wyrażeniu zgody).', law: 'art. 63 ust. 3 Pgg' },
  { id: 's7', title: 'Wnieś opłatę egzaminacyjną', body: 'W 2026 r. 411,54 zł na rachunek Prezesa WUG (NBP O/O Katowice 46 1010 1212 0010 5222 3100 0000) lub gotówką w kasie urzędu, przy którym działa komisja. Dowód wpłaty przekaż komisji przed egzaminem – nie dołączasz go do wniosku. W tytule: imię i nazwisko, organ i rodzaj kwalifikacji. Gdy egzamin wyznaczono w kolejnym roku – obowiązuje stawka z roku egzaminu.', law: 'art. 63 ust. 4, art. 66 Pgg' },
  { id: 's8', title: 'Przygotuj się do egzaminu', body: 'Zakres: znajomość przepisów prawa geologicznego i górniczego oraz innych przepisów stosowanych w ruchu zakładu, a także zagadnień związanych z prowadzeniem ruchu danego rodzaju zakładu i występujących zagrożeń (art. 54 pkt 1) – albo zagadnień ratownictwa (art. 54 pkt 2). Korzystaj z działu „Prawo” i „Pytania”.', law: 'art. 54 pkt 1–2, art. 64 Pgg' },
  { id: 's9', title: 'Egzamin', body: 'Dyrektor OUG: wyłącznie ustny. Prezes WUG: pisemny (test 20 pytań jednokrotnego wyboru) + ustny; do ustnego trzeba min. 75% poprawnych odpowiedzi. Zespół 3–5 osób; wynik „pozytywny” albo „negatywny” – większością głosów, przy równości decyduje przewodniczący.', law: 'art. 65 Pgg; § 10 rozp.' },
  { id: 's10', title: 'Świadectwo', body: 'Po wyniku pozytywnym organ wydaje świadectwo stwierdzające posiadanie kwalifikacji (wzór – zał. nr 7 do rozporządzenia). Opłata za wydanie świadectwa w 2026 r.: 49,45 zł. Twoje nazwisko i rodzaj kwalifikacji trafią do wykazu w BIP organu.', law: 'art. 58, art. 66, art. 70 Pgg' },
  { id: 's11', title: 'Jeśli wynik negatywny – egzamin ponowny', body: 'Najwcześniej po 6 miesiącach od egzaminu. Wniosek złóż przed upływem roku od egzaminu z wynikiem negatywnym: imię i nazwisko, adres, oznaczenie postępowania (z pisma o pierwszym terminie). Bez ponownych dokumentów; można pismem lub e-mailem. Ponownie wnosisz opłatę.', law: 'art. 65 ust. 8–10 Pgg' }
];

window.PROCEDURE_GEO = [
  { title: 'Organ', body: 'Kat. I–IX – minister właściwy do spraw środowiska; kat. XIII – marszałek województwa właściwy wg miejsca zamieszkania lub wykonywania czynności (art. 51 Pgg).' },
  { title: 'Terminy', body: 'Terminy składania wniosków oraz terminy i miejsca egzaminów ustala organ i publikuje w BIP co najmniej 30 dni przed egzaminem (art. 63 ust. 2 Pgg).' },
  { title: 'Wniosek i załączniki', body: 'Jak w górnictwie (art. 61 ust. 2–3 Pgg) oraz wykaz opracowań sporządzonych z udziałem kandydata, potwierdzony przez podmiot, na rzecz którego je sporządzono, lub przez archiwum geologiczne (albo wykaz opracowań sprawdzanych w urzędzie – dla pracowników administracji geologicznej).' },
  { title: 'Egzamin', body: 'Sprawdza się znajomość prawa geologicznego i górniczego (I–IX i XIII), prawa wodnego (IV, V), prawa budowlanego (VI, VII), prawa ochrony środowiska (I–IX) oraz umiejętność praktycznego zastosowania wiedzy (art. 64 pkt 1 Pgg). Zespół egzaminacyjny: 4 osoby (§ 6 rozp. 2026).' },
  { title: 'Ważność dopuszczenia', body: 'Dopuszczenie do egzaminu zachowuje ważność 3 lata od doręczenia informacji o dopuszczeniu (art. 65 ust. 11 pkt 1 Pgg).' },
  { title: 'Wynik negatywny', body: 'Ponowny egzamin w najbliższym możliwym terminie ustalonym przez organ administracji geologicznej (art. 65 ust. 8 pkt 2 Pgg); wniosek – przed upływem roku.' },
  { title: 'Opłaty', body: 'Opłata egzaminacyjna i za świadectwo wg art. 66 Pgg – aktualne stawki ogłasza obwieszczeniem minister właściwy do spraw środowiska (M.P.). Sprawdź w BIP organu.' }
];

// Lista kontrolna dokumentów
window.CHECKLIST = [
  { id: 'c1', t: 'Formularz wniosku (właściwy dla organu i rodzaju zakładu)', req: true },
  { id: 'c2', t: 'Odpis lub uwierzytelniona kopia dyplomu (lub świadectwa technika)', req: true },
  { id: 'c3', t: 'Suplement do dyplomu / wykaz przedmiotów lub efektów uczenia się – gdy kierunek nie wynika wprost z nazwy (art. 57 ust. 1 Pgg)', req: false },
  { id: 'c4', t: 'Świadectwo ukończenia studiów podyplomowych', req: false },
  { id: 'c5', t: 'Zaświadczenie uczelni o złożeniu egzaminów uzupełniających (art. 57 ust. 2 Pgg)', req: false },
  { id: 'c6', t: 'Dokument potwierdzający tytuł zawodowy / kwalifikacje w zawodzie / uprawnienia budowlane', req: false },
  { id: 'c7', t: 'Świadectwa pracy i/lub zaświadczenia o zatrudnieniu (z okresami i stanowiskami)', req: true },
  { id: 'c8', t: 'Opinia o przebiegu pracy zawodowej (dla mierniczego/geologa – podpisana przez kierownika działu mierniczego/geologicznego)', req: true },
  { id: 'c9', t: 'Opis doświadczenia zawodowego we wniosku – z naciskiem na zakres czynności objętych kwalifikacją', req: true },
  { id: 'c10', t: 'Ew. wniosek o uznanie innej praktyki za równoważną (art. 55 ust. 2a Pgg)', req: false },
  { id: 'c11', t: 'Zgoda na korespondencję elektroniczną z adresem e-mail (zalecane przez WUG)', req: false },
  { id: 'c12', t: 'Dowód wpłaty opłaty egzaminacyjnej – przekazywany komisji PRZED egzaminem, nie z wnioskiem', req: true },
  { id: 'c13', t: 'Dokument tożsamości na egzamin', req: true }
];

// Zakres wiedzy – wybrane zagadnienia (WUG)
window.TOPICS = {
  ustawa: ['zakres obowiązywania ustawy', 'definicje określone w ustawie', 'obowiązki kierownika ruchu zakładu górniczego wynikające z ustawy', 'koncesje', 'uprawnienia rzeczoznawcy', 'odpowiedzialność zawodowa wynikająca z ustawy', 'plan ruchu zakładu górniczego', 'wyroby stosowane w zakładach górniczych', 'oddawanie do ruchu obiektów, maszyn, urządzeń, ścian i oddziałów', 'klasyfikacja złóż (pokładów) w zakresie występujących zagrożeń', 'zgłaszanie wypadków i zdarzeń do organu nadzoru górniczego', 'odstąpienie od przepisów wykonawczych do ustawy', 'ratownictwo górnicze', 'plan ratownictwa górniczego', 'prowadzenie akcji ratowniczej', 'fundusz likwidacji zakładu górniczego', 'odpowiedzialność za szkody', 'organy nadzoru górniczego', 'kary pieniężne'],
  rozporzadzenia: ['ocena ryzyka zawodowego', 'dokument bezpieczeństwa', 'współdziałanie działów ruchu oraz służb specjalistycznych', 'organizacja służby dyspozytorskiej', 'kontrole wyrobisk oraz obiektów i urządzeń', 'zatrudnianie podmiotów w ruchu zakładu górniczego', 'dokumentacja obowiązująca w ruchu zakładu górniczego', 'podstawowe obiekty, maszyny i urządzenia', 'ściany i oddziały prowadzone w warunkach specjalnych', 'roboty w warunkach zagrożenia tąpaniami', 'roboty w warunkach zagrożenia metanowego', 'kryteria prowadzenia ścian w zależności od warunków górniczo-geologicznych', 'obudowa wyrobisk korytarzowych', 'skład atmosfery kopalnianej', 'przewietrzanie wentylatorami głównymi', 'wentylacja lutniowa', 'odmetanowanie górotworu', 'zabezpieczenia przed przeniesieniem wybuchu pyłu węglowego', 'zagrożenie pożarem endogenicznym i egzogenicznym', 'obudowa wyrobisk eksploatacyjnych', 'zabezpieczenie przed dopływem wody', 'lokomotywy elektryczne, akumulatorowe i spalinowe', 'zagrożenie klimatyczne', 'zagrożenie radiacyjne', 'zakres rozporządzenia o ratownictwie górniczym', 'skład drużyny ratowniczej przedsiębiorcy', 'współdziałanie przedsiębiorcy i jednostki ratownictwa', 'zatrudnianie zastępów ratowniczych w zakładzie', 'organizacja, wyposażenie i zadania JRG', 'kursy, szkolenia i seminaria w ratownictwie', 'prace profilaktyczne', 'organizacja prowadzenia akcji ratowniczej', 'specjalistyczne badania lekarskie i psychologiczne w ratownictwie', 'dokumentacja w zakresie ratownictwa górniczego', 'akcje ratownicze w zakładach podziemnych wg rodzaju zdarzenia i zagrożeń', 'tamy izolacyjne o konstrukcji przeciwwybuchowej', 'postępowanie w przypadku znalezienia środków strzałowych', 'składy materiałów wybuchowych pod ziemią', 'przechowywanie, transport i postępowanie ze środkami strzałowymi', 'metryka strzałowa i dokumentacja strzałowa', 'roboty strzałowe w warunkach zagrożenia metanowego i pyłowego', 'roboty strzałowe w szczególnych warunkach górniczo-geologicznych', 'klasyfikacja zagrożeń naturalnych'],
  ratownictwo: ['przepisy o ruchu zakładu górniczego, akcjach ratowniczych i pracach profilaktycznych', 'organizacja i zadania ratownictwa górniczego', 'wyposażenie jednostek ratownictwa górniczego', 'metody prowadzenia akcji ratowniczych i prac profilaktycznych', 'metody prowadzenia szkoleń i ćwiczeń ratowniczych', 'zasady udzielania pomocy przedmedycznej', 'działalność pogotowi specjalistycznych']
};

window.PROC_ACTS = [
  { title: 'Ustawa z 14 czerwca 1960 r. – Kodeks postępowania administracyjnego', addr: 'Dz.U. 2025 poz. 1691', url: 'https://isap.sejm.gov.pl/isap.nsf/DocDetails.xsp?id=WDU20250001691' },
  { title: 'Ustawa z 22 grudnia 2015 r. o zasadach uznawania kwalifikacji zawodowych nabytych w państwach członkowskich UE', addr: 'Dz.U. 2023 poz. 334', url: 'https://isap.sejm.gov.pl/isap.nsf/DocDetails.xsp?id=WDU20230000334' },
  { title: 'Rozporządzenie MAP z 31 maja 2023 r. w sprawie upoważnienia do uznawania kwalifikacji do wykonywania górniczych zawodów regulowanych', addr: 'Dz.U. 2023 poz. 1061', url: 'https://isap.sejm.gov.pl/isap.nsf/DocDetails.xsp?id=WDU20230001061' }
];

window.GLOSSARY = [
  ['Dozór ruchu', 'Najniższy szczebel osób kierownictwa i dozoru ruchu (np. sztygar zmianowy, nadgórnik). Kwalifikacje stwierdza dyrektor OUG (wyj. składowanie CO₂ – Prezes WUG).'],
  ['Wyższy dozór ruchu', 'Osoby kierujące oddziałami / robotami (np. sztygar oddziałowy, kierownik robót). Wymaga praktyki w dozorze.'],
  ['Kierownik działu ruchu', 'Kieruje działem (górniczym, energomechanicznym, wentylacji, tąpań, techniki strzałowej, BHP, mierniczym, geologicznym…). Kwalifikacje obejmują zastępcę.'],
  ['Kierownik ruchu zakładu górniczego (KRZG)', 'Osoba odpowiedzialna za ruch zakładu. W podziemnych zakładach – kwalifikacje stwierdza Prezes WUG; w odkrywkowych i otworowych – dyrektor OUG.'],
  ['Zakład z art. 2 ust. 1 Pgg', 'Działalność: odwadnianie zlikwidowanych zakładów, roboty w wyrobiskach zlikwidowanych kopalń (turystyka, lecznictwo, rekreacja), roboty podziemne do celów naukowych/szkoleniowych, drążenie tuneli techniką górniczą, likwidacja tych obiektów.'],
  ['Zakład wykonujący roboty geologiczne (art. 86 Pgg)', 'Roboty geologiczne przy poszukiwaniu i rozpoznawaniu złóż i kompleksów składowania CO₂, a także inne roboty geologiczne ze środkami strzałowymi, głębsze niż 100 m lub na obszarze górniczym.'],
  ['Przygotowanie zawodowe (art. 54 Pgg)', 'Znajomość przepisów i zagadnień (sprawdzana na egzaminie) oraz wykształcenie / tytuł zawodowy / studia podyplomowe / egzaminy uzupełniające (sprawdzane przy dopuszczeniu).'],
  ['Doświadczenie zawodowe (art. 55 Pgg)', 'Praktyka określona czasem trwania i rodzajem czynności (praktyka w ruchu, miernicza, geologiczna, geofizyczna, ratownicza) – na umowie o pracę lub cywilnoprawnej.'],
  ['Egzaminy uzupełniające', 'Egzaminy z przedmiotów wskazanych w rozporządzeniu, zdawane na uczelni realizującej odpowiedni program; dokumentowane zaświadczeniem uczelni (art. 57 ust. 2 Pgg).'],
  ['Art. 55 ust. 2a Pgg', 'Na wniosek kandydata organ może uznać za praktykę czynności wykonywane w zakładach działających inną metodą, jeśli udokumentowane doświadczenie odpowiada wymaganej praktyce.'],
  ['OUG', 'Okręgowy urząd górniczy – 10 urzędów (Gdańsk, Katowice, Kielce, Kraków, Krosno, Lublin, Poznań, Rybnik/Jankowice, Warszawa, Wrocław).'],
  ['Świadectwo', 'Dokument stwierdzający posiadanie kwalifikacji (wzór – zał. nr 7 rozp. 2024). Osoby z kwalifikacjami są wpisywane do wykazu w BIP (art. 70 Pgg).']
];
