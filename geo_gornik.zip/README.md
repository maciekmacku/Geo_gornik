# Kompendium kwalifikacji górniczych (PWA)

Aplikacja internetowa typu PWA o stwierdzaniu kwalifikacji górniczych, wiertniczych i geologicznych:
wymagania (wykształcenie + praktyka), procedura przed dyrektorem OUG / Prezesem WUG / administracją geologiczną,
dokumenty i formularze, opłaty, akty prawne oraz banki pytań WUG (geolog i mierniczy górniczy) w trybie fiszek
i symulacji egzaminu. Działa offline po pierwszym uruchomieniu (w tym 6 dołączonych PDF-ów).

Stan prawny i opłaty: 2 października 2026 r.

## Uruchomienie lokalne

```bash
cd kompendium
python3 -m http.server 8765
```

Otwórz http://localhost:8765 – w Chrome/Edge pojawi się przycisk „Zainstaluj”.

## Publikacja

Service worker (offline, instalacja) wymaga HTTPS. Wystarczy wgrać cały folder na dowolny hosting statyczny
(GitHub Pages, Netlify, Cloudflare Pages, serwer firmowy). Brak kroku budowania i zależności.

Po zmianie plików podbij `VERSION` w `sw.js`, aby użytkownicy dostali aktualizację.

## Struktura

- `index.html`, `css/app.css`, `js/app.js` – interfejs (bez frameworków)
- `js/data.js` – kwalifikacje, tabele, procedura, opłaty, OUG, słownik
- `js/acts.js` – akty prawne zweryfikowane w API Sejmu (ELI), z tekstami jednolitymi i statusem
- `js/questions.js` – 553 + 467 pytań WUG (tylko treść; WUG nie publikuje odpowiedzi)
- `docs/` – PDF: rozp. Dz.U. 2024 poz. 992, Pgg Dz.U. 2026 poz. 69, rozp. Dz.U. 2026 poz. 249, pytania WUG, rozp. o OUG
- `sw.js`, `manifest.webmanifest`, `icons/` – PWA

## Źródła

- WUG: https://www.gov.pl/web/wug/kwalifikacje-gornicze oraz archiwum https://www.wug.gov.pl/prawo/kwalifikacje_gornicze
- ISAP / API ELI Sejmu: https://isap.sejm.gov.pl, https://api.sejm.gov.pl/eli

Kompendium ma charakter informacyjny. Wiążące są teksty aktów prawnych i rozstrzygnięcia organów.
